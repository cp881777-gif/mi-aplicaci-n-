import { TargetAi, AppType } from '../types';

export const TECH_OPTIONS = {
  frontend: [
    { id: 'react_vite', label: 'React + Vite (TypeScript)', popular: true },
    { id: 'nextjs', label: 'Next.js 14/15 (App Router)', popular: true },
    { id: 'vue_vite', label: 'Vue 3 + Vite', popular: false },
    { id: 'sveltekit', label: 'SvelteKit', popular: false },
    { id: 'react_native', label: 'React Native (Expo)', popular: true },
    { id: 'flutter', label: 'Flutter (Dart)', popular: false },
    { id: 'vanilla_html', label: 'HTML5 + Tailwind CDN', popular: false }
  ],
  uiLibrary: [
    { id: 'tailwind', label: 'Tailwind CSS v4', popular: true },
    { id: 'shadcn', label: 'Shadcn UI + Tailwind', popular: true },
    { id: 'lucide_radix', label: 'Radix UI + Lucide Icons', popular: true },
    { id: 'chakra', label: 'Chakra UI', popular: false },
    { id: 'material_ui', label: 'MUI (Material UI)', popular: false },
    { id: 'daisyui', label: 'DaisyUI', popular: false }
  ],
  backend: [
    { id: 'supabase', label: 'Supabase (BaaS / Serverless)', popular: true },
    { id: 'node_express', label: 'Node.js + Express', popular: true },
    { id: 'node_nest', label: 'NestJS (Node.js)', popular: false },
    { id: 'python_fastapi', label: 'Python (FastAPI)', popular: true },
    { id: 'firebase', label: 'Firebase / Firestore', popular: false },
    { id: 'next_api', label: 'Next.js API Routes / Server Actions', popular: true },
    { id: 'go_gin', label: 'Go (Gin Framework)', popular: false }
  ],
  database: [
    { id: 'postgresql', label: 'PostgreSQL + Prisma / Drizzle', popular: true },
    { id: 'supabase_pg', label: 'Supabase PostgreSQL', popular: true },
    { id: 'mongodb', label: 'MongoDB + Mongoose', popular: false },
    { id: 'sqlite', label: 'SQLite (Better-Sqlite3 / Turso)', popular: true },
    { id: 'redis', label: 'Redis (Cache / Realtime)', popular: false }
  ],
  auth: [
    { id: 'clerk', label: 'Clerk Auth', popular: true },
    { id: 'supabase_auth', label: 'Supabase Auth', popular: true },
    { id: 'nextauth', label: 'NextAuth.js / Auth.js', popular: true },
    { id: 'custom_jwt', label: 'Custom JWT / Bcrypt', popular: false },
    { id: 'firebase_auth', label: 'Firebase Authentication', popular: false }
  ],
  payments: [
    { id: 'stripe', label: 'Stripe Payments / Subscriptions', popular: true },
    { id: 'lemon_squeezy', label: 'Lemon Squeezy (MoR)', popular: true },
    { id: 'paddle', label: 'Paddle', popular: false },
    { id: 'mercado_pago', label: 'MercadoPago (LATAM)', popular: true },
    { id: 'none', label: 'Ninguno / Sin pagos por ahora', popular: false }
  ],
  deploy: [
    { id: 'vercel', label: 'Vercel', popular: true },
    { id: 'netlify', label: 'Netlify', popular: false },
    { id: 'render', label: 'Render / Railway', popular: true },
    { id: 'docker', label: 'Docker + VPS (Hetznr / DigitalOcean)', popular: false }
  ]
};

export const TARGET_AI_OPTIONS: { id: TargetAi; name: string; desc: string; icon: string }[] = [
  {
    id: 'claude',
    name: 'Claude 3.7 / 3.5 Sonnet',
    desc: 'Ideal para código complejo, arquitecturas y seguimiento de instrucciones largas',
    icon: 'Sparkles'
  },
  {
    id: 'chatgpt',
    name: 'ChatGPT / GPT-4o',
    desc: 'Excelente para explicaciones paso a paso y refactorización',
    icon: 'Bot'
  },
  {
    id: 'cursor',
    name: 'Cursor AI / Composer',
    desc: 'Optimizado para context-window en IDEs con reglas .cursorrules',
    icon: 'Code2'
  },
  {
    id: 'bolt',
    name: 'Bolt.new / StackBlitz AI',
    desc: 'Generación directa de proyectos full-stack ejecutables en navegador',
    icon: 'Zap'
  },
  {
    id: 'v0',
    name: 'v0 by Vercel',
    desc: 'Especializado en interfaces React, Shadcn UI y Tailwind CSS',
    icon: 'Layout'
  },
  {
    id: 'windsurf',
    name: 'Windsurf / Codeium Cascade',
    desc: 'Navegación fluida por código y desarrollo multi-archivo',
    icon: 'Terminal'
  },
  {
    id: 'copilot',
    name: 'GitHub Copilot Workspace',
    desc: 'Integración continua con repositorios y pull requests',
    icon: 'GitPullRequest'
  }
];

export const APP_TYPES: { id: AppType; titleEs: string; titleEn: string; icon: string; desc: string }[] = [
  { id: 'saas', titleEs: 'SaaS / Web App Completa', titleEn: 'SaaS / Web Application', icon: 'Globe', desc: 'Plataforma con auth, suscripciones, usuarios y dashboard' },
  { id: 'ecommerce', titleEs: 'E-Commerce / Tienda', titleEn: 'E-Commerce Store', icon: 'ShoppingCart', desc: 'Catálogo de productos, carrito, Stripe y gestión de pedidos' },
  { id: 'dashboard', titleEs: 'Dashboard & Analíticas', titleEn: 'Dashboard & Analytics', icon: 'BarChart3', desc: 'Métricas en tiempo real, tablas interactivas y gráficos' },
  { id: 'ai_app', titleEs: 'Aplicación de IA / Wrapper', titleEn: 'AI App / LLM Tool', icon: 'Cpu', desc: 'Generador de contenido, chatbots RAG o agentes de IA' },
  { id: 'crm', titleEs: 'CRM / Gestión de Clientes', titleEn: 'CRM / Business Tool', icon: 'Users', desc: 'Pipeline de ventas, clientes, tareas y seguimiento' },
  { id: 'mobile', titleEs: 'App Móvil (iOS & Android)', titleEn: 'Mobile App', icon: 'Smartphone', desc: 'Interface táctil, notificaciones y experiencia móvil native' },
  { id: 'edtech', titleEs: 'Plataforma EdTech / Cursos', titleEn: 'EdTech / Learning', icon: 'GraduationCap', desc: 'Lecciones en video, quizzes, progreso y certificados' },
  { id: 'health', titleEs: 'App de Salud & Fitness', titleEn: 'Health & Fitness', icon: 'Activity', desc: 'Seguimiento de rutinas, calorías, metas y recordatorios' },
  { id: 'game', titleEs: 'Juego Web / Canvas', titleEn: 'Web Game / Interactive', icon: 'Gamepad2', desc: 'Juegos interactivos 2D/3D con física y puntuación' },
  { id: 'custom', titleEs: 'Aplicación Personalizada', titleEn: 'Custom Application', icon: 'Wrench', desc: 'Construye cualquier idea con requerimientos a la medida' }
];

export const DEFAULT_FEATURES = {
  auth: true,
  darkMode: true,
  realtime: false,
  subscriptions: true,
  adminPanel: true,
  fileUpload: true,
  i18n: false,
  aiIntegration: true,
  searchFilter: true,
  exportPdfCsv: true,
  rbac: true,
  notifications: true,
  customFeatures: []
};
