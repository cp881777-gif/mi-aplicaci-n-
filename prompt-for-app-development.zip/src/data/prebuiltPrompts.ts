import { PrebuiltTemplate } from '../types';

export const PREBUILT_TEMPLATES: PrebuiltTemplate[] = [
  {
    id: 'saas-starter',
    title: {
      es: 'SaaS B2B Multi-tenant con Pagos',
      en: 'B2B Multi-tenant SaaS with Payments'
    },
    subtitle: {
      es: 'React 19 + Tailwind CSS + Supabase Auth & DB + Stripe Subscriptions',
      en: 'React 19 + Tailwind CSS + Supabase Auth & DB + Stripe Subscriptions'
    },
    category: 'saas',
    iconName: 'Sparkles',
    color: 'from-purple-600 to-indigo-600',
    tags: ['SaaS', 'Stripe', 'Supabase', 'TypeScript', 'Dashboard'],
    config: {
      title: 'Plataforma SaaS B2B de Gestión de Proyectos',
      description: 'Una aplicación web completa para que equipos gestionen proyectos, asignen tareas, midan tiempos y gestionen suscripciones de pago.',
      targetAudience: 'Startups, agencias y equipos de trabajo remotos',
      appType: 'saas',
      complexity: 'standard',
      stack: {
        frontend: 'React + Vite (TypeScript)',
        uiLibrary: 'Tailwind CSS v4 + Lucide Icons',
        backend: 'Supabase (BaaS)',
        database: 'Supabase PostgreSQL',
        auth: 'Supabase Auth',
        payments: 'Stripe Payments / Subscriptions',
        deploy: 'Vercel'
      },
      features: {
        auth: true,
        darkMode: true,
        realtime: true,
        subscriptions: true,
        adminPanel: true,
        fileUpload: true,
        i18n: false,
        aiIntegration: true,
        searchFilter: true,
        exportPdfCsv: true,
        rbac: true,
        notifications: true,
        customFeatures: ['Kanban interactive board', 'Time tracking timer', 'Team activity logs']
      },
      targetAi: 'claude',
      language: 'es'
    }
  },
  {
    id: 'ecommerce-modern',
    title: {
      es: 'E-Commerce Ultra-Rápido con Checkout',
      en: 'Ultra-Fast E-Commerce with Checkout'
    },
    subtitle: {
      es: 'Catálogo de productos, filtro dinámico, carrito local y pasarela MercadoPago / Stripe',
      en: 'Product catalog, dynamic filter, local cart, and Stripe/MercadoPago checkout'
    },
    category: 'ecommerce',
    iconName: 'ShoppingCart',
    color: 'from-emerald-600 to-teal-600',
    tags: ['E-Commerce', 'Stripe', 'Cart', 'Products', 'React'],
    config: {
      title: 'Tienda Online Neumórfica & Moderna',
      description: 'Plataforma e-commerce con catálogo con filtros multi-categoría, vista detallada de producto, carrito flotante con persistencia y panel de administración de inventario.',
      targetAudience: 'Compradores finales y administradores de tienda',
      appType: 'ecommerce',
      complexity: 'standard',
      stack: {
        frontend: 'React + Vite (TypeScript)',
        uiLibrary: 'Tailwind CSS v4',
        backend: 'Node.js + Express',
        database: 'PostgreSQL + Prisma',
        auth: 'Clerk Auth',
        payments: 'Stripe Payments / Subscriptions',
        deploy: 'Vercel'
      },
      features: {
        auth: true,
        darkMode: true,
        realtime: false,
        subscriptions: false,
        adminPanel: true,
        fileUpload: true,
        i18n: true,
        aiIntegration: false,
        searchFilter: true,
        exportPdfCsv: true,
        rbac: true,
        notifications: true,
        customFeatures: ['Filtros por precio y valoraciones', 'Wishlist / Favoritos', 'Gestor de stock en tiempo real']
      },
      targetAi: 'cursor',
      language: 'es'
    }
  },
  {
    id: 'ai-studio-agent',
    title: {
      es: 'AI Studio / Generador de Contenido RAG',
      en: 'AI Studio & Content Generator'
    },
    subtitle: {
      es: 'Integración OpenAI/Claude, prompts personalizados, streaming de texto e historial',
      en: 'OpenAI/Claude integration, custom prompts, text streaming, and history'
    },
    category: 'ai_app',
    iconName: 'Cpu',
    color: 'from-blue-600 to-cyan-600',
    tags: ['AI Agent', 'OpenAI', 'Claude API', 'Streaming', 'LLM'],
    config: {
      title: 'AI Studio: Generador de Contenido Multi-Modelo',
      description: 'Una app donde creadores pueden seleccionar modelos de IA, ingresar prompts, adjuntar archivos PDF y recibir respuestas en streaming con sintaxis resaltada y exportación.',
      targetAudience: 'Creadores de contenido, marketers y desarrolladores',
      appType: 'ai_app',
      complexity: 'standard',
      stack: {
        frontend: 'Next.js 14/15 (App Router)',
        uiLibrary: 'Shadcn UI + Tailwind',
        backend: 'Next.js API Routes / Server Actions',
        database: 'Supabase PostgreSQL',
        auth: 'Clerk Auth',
        payments: 'Lemon Squeezy (MoR)',
        deploy: 'Vercel'
      },
      features: {
        auth: true,
        darkMode: true,
        realtime: true,
        subscriptions: true,
        adminPanel: true,
        fileUpload: true,
        i18n: false,
        aiIntegration: true,
        searchFilter: true,
        exportPdfCsv: true,
        rbac: false,
        notifications: true,
        customFeatures: ['Streaming SSE en tiempo real', 'Historial de chats por carpetas', 'Plantillas de prompts reutilizables']
      },
      targetAi: 'bolt',
      language: 'es'
    }
  },
  {
    id: 'dashboard-analytics',
    title: {
      es: 'Dashboard de Finanzas & Métricas Executive',
      en: 'Executive Finance & Analytics Dashboard'
    },
    subtitle: {
      es: 'Gráficos interactivos, tarjetas KPI, tablas con ordenamiento y reportes PDF',
      en: 'Interactive charts, KPI cards, sortable tables, and PDF report exports'
    },
    category: 'dashboard',
    iconName: 'BarChart3',
    color: 'from-amber-600 to-orange-600',
    tags: ['Analytics', 'Recharts', 'KPIs', 'Data Viz', 'Export'],
    config: {
      title: 'Executive Financial & Metrics Dashboard',
      description: 'Panel ejecutivo con métricas financieras (MRR, Churn, ARPU), gráficos de tendencia interactivos, filtros de rango de fechas y exportación automática a PDF y CSV.',
      targetAudience: 'Directores ejecutivos, contadores y analistas de datos',
      appType: 'dashboard',
      complexity: 'standard',
      stack: {
        frontend: 'React + Vite (TypeScript)',
        uiLibrary: 'Tailwind CSS v4 + Radix UI',
        backend: 'Python (FastAPI)',
        database: 'PostgreSQL + Prisma',
        auth: 'NextAuth.js / Auth.js',
        payments: 'Ninguno / Sin pagos por ahora',
        deploy: 'Render / Railway'
      },
      features: {
        auth: true,
        darkMode: true,
        realtime: true,
        subscriptions: false,
        adminPanel: true,
        fileUpload: true,
        i18n: true,
        aiIntegration: true,
        searchFilter: true,
        exportPdfCsv: true,
        rbac: true,
        notifications: true,
        customFeatures: ['Widget de proyección con IA', 'Selector de rangos de tiempo (7d, 30d, 1y)', 'Exportador de reporte en PDF con plantilla']
      },
      targetAi: 'v0',
      language: 'es'
    }
  },
  {
    id: 'crm-workflow',
    title: {
      es: 'CRM Completo con Embudo de Ventas',
      en: 'Complete CRM with Sales Pipeline'
    },
    subtitle: {
      es: 'Pipeline Drag-and-Drop, fichas de clientes, historial de interacciones y recordatorios',
      en: 'Drag-and-Drop pipeline, customer files, interaction history, and reminders'
    },
    category: 'crm',
    iconName: 'Users',
    color: 'from-rose-600 to-pink-600',
    tags: ['CRM', 'Pipeline', 'Drag & Drop', 'B2B', 'Reminders'],
    config: {
      title: 'Smart CRM & Pipeline Manager',
      description: 'Sistema CRM para equipos comerciales con tablero Kanban de ventas drag-and-drop, gestión de contactos, registro de llamadas/emails y automatización de notas.',
      targetAudience: 'Equipos de ventas, representantes comerciales y freelancers',
      appType: 'crm',
      complexity: 'standard',
      stack: {
        frontend: 'React + Vite (TypeScript)',
        uiLibrary: 'Tailwind CSS v4',
        backend: 'Supabase (BaaS)',
        database: 'Supabase PostgreSQL',
        auth: 'Supabase Auth',
        payments: 'Ninguno / Sin pagos por ahora',
        deploy: 'Vercel'
      },
      features: {
        auth: true,
        darkMode: true,
        realtime: true,
        subscriptions: false,
        adminPanel: true,
        fileUpload: true,
        i18n: false,
        aiIntegration: true,
        searchFilter: true,
        exportPdfCsv: true,
        rbac: true,
        notifications: true,
        customFeatures: ['Tablero Kanban Drag & Drop para oportunidades', 'Historial de actividades cronológico', 'Resumen diario generado por IA']
      },
      targetAi: 'claude',
      language: 'es'
    }
  },
  {
    id: 'fitness-tracker',
    title: {
      es: 'App de Salud, Fitness & Nutrición',
      en: 'Health, Fitness & Nutrition App'
    },
    subtitle: {
      es: 'Registro de ejercicios, contador de macros, progreso visual y calendario',
      en: 'Workout logging, macro counter, visual progress, and calendar'
    },
    category: 'health',
    iconName: 'Activity',
    color: 'from-emerald-500 to-green-600',
    tags: ['Fitness', 'Health', 'PWA', 'Tracker', 'Mobile-Friendly'],
    config: {
      title: 'FitTrack Pro: Tu Entrenador & Nutricionista AI',
      description: 'Aplicación web progresiva (PWA) para planificar rutinas de gimnasio, registrar repeticiones/peso, escanear o buscar alimentos para macros e identificar tendencias físicas.',
      targetAudience: 'Atletas, entusiastas del fitness y entrenadores personales',
      appType: 'health',
      complexity: 'mvp',
      stack: {
        frontend: 'React + Vite (TypeScript)',
        uiLibrary: 'Tailwind CSS v4',
        backend: 'Supabase (BaaS)',
        database: 'Supabase PostgreSQL',
        auth: 'Supabase Auth',
        payments: 'Stripe Payments / Subscriptions',
        deploy: 'Vercel'
      },
      features: {
        auth: true,
        darkMode: true,
        realtime: false,
        subscriptions: true,
        adminPanel: false,
        fileUpload: true,
        i18n: false,
        aiIntegration: true,
        searchFilter: true,
        exportPdfCsv: true,
        rbac: false,
        notifications: true,
        customFeatures: ['Calculadora de macronutrientes', 'Graficador de evolución de peso y marcas', 'Asistente de rutinas por IA']
      },
      targetAi: 'windsurf',
      language: 'es'
    }
  }
];
