export type AppType = 
  | 'saas' 
  | 'ecommerce' 
  | 'dashboard' 
  | 'mobile' 
  | 'ai_app' 
  | 'crm' 
  | 'game' 
  | 'edtech' 
  | 'health' 
  | 'custom';

export type TargetAi = 
  | 'claude' 
  | 'chatgpt' 
  | 'cursor' 
  | 'bolt' 
  | 'v0' 
  | 'windsurf' 
  | 'copilot';

export type Language = 'es' | 'en';

export interface TechStack {
  frontend: string;
  uiLibrary: string;
  backend: string;
  database: string;
  auth: string;
  payments: string;
  deploy: string;
}

export interface AppFeatures {
  auth: boolean;
  darkMode: boolean;
  realtime: boolean;
  subscriptions: boolean;
  adminPanel: boolean;
  fileUpload: boolean;
  i18n: boolean;
  aiIntegration: boolean;
  searchFilter: boolean;
  exportPdfCsv: boolean;
  rbac: boolean;
  notifications: boolean;
  customFeatures: string[];
}

export interface AppPromptConfig {
  id?: string;
  title: string;
  description: string;
  targetAudience: string;
  appType: AppType;
  complexity: 'mvp' | 'standard' | 'enterprise';
  stack: TechStack;
  features: AppFeatures;
  targetAi: TargetAi;
  language: Language;
  createdAt?: string;
}

export interface GeneratedPromptResult {
  title: string;
  masterPrompt: string;
  systemPersona: string;
  architectureDetails: string;
  folderStructure: string;
  dbSchema: string;
  roadmapPhases: {
    phase: string;
    title: string;
    promptText: string;
  }[];
  qualityChecklist: string[];
}

export interface PrebuiltTemplate {
  id: string;
  title: Record<Language, string>;
  subtitle: Record<Language, string>;
  category: AppType;
  iconName: string;
  color: string;
  config: AppPromptConfig;
  tags: string[];
}
