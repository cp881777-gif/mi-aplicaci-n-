import { AppPromptConfig, GeneratedPromptResult } from '../types';

export function generateSoftwarePrompt(config: AppPromptConfig): GeneratedPromptResult {
  const isEs = config.language === 'es';
  const { title, description, targetAudience, appType, complexity, stack, features, targetAi } = config;

  // Selected features array text
  const featureList: string[] = [];
  if (features.auth) featureList.push(isEs ? 'Autenticación de usuarios (Registro, Login, Recuperación de contraseña, OAuth)' : 'User Authentication (Sign up, Login, Password recovery, OAuth)');
  if (features.darkMode) featureList.push(isEs ? 'Soporte completo para Modo Oscuro y Claro (Dark/Light Mode con toggle persistente)' : 'Dark & Light Mode with persistent toggle');
  if (features.realtime) featureList.push(isEs ? 'Funcionalidades en tiempo real (WebSockets / Supabase Realtime / SSE)' : 'Realtime updates (WebSockets / Realtime DB / SSE)');
  if (features.subscriptions) featureList.push(isEs ? 'Pasarela de pagos y gestión de suscripciones / planes (Stripe / Lemon Squeezy)' : 'Payment gateway and subscription plans (Stripe / Lemon Squeezy)');
  if (features.adminPanel) featureList.push(isEs ? 'Panel de administración (Admin Dashboard con gestión de usuarios, roles y métricas)' : 'Admin Dashboard for users, roles, and platform metrics');
  if (features.fileUpload) featureList.push(isEs ? 'Subida de archivos e imágenes (Storage buckets con drag-and-drop y preview)' : 'File & Image Uploads (Storage with drag-and-drop & previews)');
  if (features.i18n) featureList.push(isEs ? 'Internacionalización / Multi-idioma (i18n Español / Inglés)' : 'Internationalization / Multi-language (i18n)');
  if (features.aiIntegration) featureList.push(isEs ? 'Integración con APIs de Inteligencia Artificial (OpenAI / Claude / Gemini / RAG)' : 'AI Integration (OpenAI / Claude / Gemini API / RAG)');
  if (features.searchFilter) featureList.push(isEs ? 'Búsqueda global con filtros avanzados, ordenamiento y paginación' : 'Global search with advanced filtering, sorting & pagination');
  if (features.exportPdfCsv) featureList.push(isEs ? 'Exportación de datos e informes a formato PDF y CSV / Excel' : 'Data export to PDF and CSV / Excel formats');
  if (features.rbac) featureList.push(isEs ? 'Control de acceso basado en roles (RBAC: Admin, Editor, Usuario)' : 'Role-Based Access Control (RBAC: Admin, Editor, User)');
  if (features.notifications) featureList.push(isEs ? 'Sistema de notificaciones Toast y Centro de notificaciones in-app' : 'Toast notification system and in-app Notification Center');
  
  if (features.customFeatures && features.customFeatures.length > 0) {
    features.customFeatures.forEach(cf => {
      if (cf.trim()) featureList.push(cf.trim());
    });
  }

  // System Persona
  const systemPersona = isEs
    ? `Actúa como un Arquitecto de Software Principal y Desarrollador Full-Stack Senior especializado en ${stack.frontend} y ${stack.backend}. Tu objetivo es guiar y generar el código fuente completo, robusto, limpio y listo para producción para la aplicación "${title}". Debes aplicar principios SOLID, diseño responsive moderno con Tailwind CSS, manejo estricto de tipos con TypeScript, y arquitectura modular por componentes.`
    : `Act as a Lead Software Architect and Senior Full-Stack Engineer specializing in ${stack.frontend} and ${stack.backend}. Your objective is to build and generate complete, robust, clean, and production-ready source code for "${title}". Follow SOLID principles, modern responsive design with Tailwind CSS, strict TypeScript type-safety, and clean modular component architecture.`;

  // Folder Structure
  const folderStructure = `src/
├── assets/            # Imágenes, íconos y estáticos
├── components/        # Componentes UI reutilizables
│   ├── ui/            # Botones, Modales, Cards, Inputs, Badges, Tabs, Skeletons
│   ├── layout/        # Navbar, Sidebar, Footer, Layout Wrapper
│   └── shared/        # Modales comunes, Toasts, Confirmaciones
├── features/          # Módulos por dominio
│   ├── auth/          # Login, Register, Auth Context/Provider
│   ├── dashboard/     # Widgets, Métricas, Gráficos
│   ├── ${appType === 'ecommerce' ? 'products' : appType === 'crm' ? 'leads' : 'content'}/ # Módulo principal de la app
│   └── settings/      # Configuración de perfil, tema y suscripciones
├── hooks/             # Custom Hooks (useAuth, useTheme, useDebounce, etc.)
├── services/          # Llamadas a API, clientes de Supabase/Backend
├── types/             # Definiciones e interfaces de TypeScript
├── utils/             # Helpers, formateadores de fecha/moneda, cn()
├── App.tsx            # Componente raíz con Router y Providers
└── main.tsx           # Punto de entrada de Vite / Next.js`;

  // DB Schema simulation
  const dbSchema = isEs ? `// Esquema de Base de Datos y Modelos (TypeScript / Prisma / PostgreSQL)

interface User {
  id: string;
  email: string;
  name: string;
  avatarUrl?: string;
  role: 'admin' | 'member' | 'guest';
  createdAt: string;
  updatedAt: string;
}

interface Subscription {
  id: string;
  userId: string;
  planId: 'free' | 'pro' | 'enterprise';
  status: 'active' | 'canceled' | 'past_due';
  stripeCustomerId?: string;
  currentPeriodEnd: string;
}

interface ${appType === 'ecommerce' ? 'Product' : appType === 'crm' ? 'Lead' : appType === 'ai_app' ? 'AiPromptItem' : 'Item'} {
  id: string;
  userId: string;
  title: string;
  description: string;
  status: string;
  category: string;
  metadata: Record<string, any>;
  createdAt: string;
  updatedAt: string;
}` : `// Database Schema & Data Models (TypeScript / Prisma / PostgreSQL)

export interface User {
  id: string;
  email: string;
  name: string;
  avatarUrl?: string;
  role: 'admin' | 'member' | 'guest';
  createdAt: string;
  updatedAt: string;
}

export interface Subscription {
  id: string;
  userId: string;
  planId: 'free' | 'pro' | 'enterprise';
  status: 'active' | 'canceled' | 'past_due';
  stripeCustomerId?: string;
  currentPeriodEnd: string;
}

export interface ${appType === 'ecommerce' ? 'Product' : appType === 'crm' ? 'Lead' : appType === 'ai_app' ? 'AiPromptItem' : 'Item'} {
  id: string;
  userId: string;
  title: string;
  description: string;
  status: string;
  category: string;
  metadata: Record<string, any>;
  createdAt: string;
  updatedAt: string;
}`;

  // AI Target Specific Tuning Instructions
  let aiTuningNote = '';
  switch (targetAi) {
    case 'bolt':
      aiTuningNote = isEs 
        ? 'NOTA PARA BOLT.NEW: Crea todos los archivos listos para ejecutar inmediatamente en el navegador con Vite + Tailwind CSS. No dejes comentarios TODO ni código incompleto.'
        : 'NOTE FOR BOLT.NEW: Create all files fully ready to execute immediately in the browser with Vite + Tailwind CSS. Avoid TODO comments or placeholder code.';
      break;
    case 'cursor':
      aiTuningNote = isEs 
        ? 'NOTA PARA CURSOR AI: Genera el archivo .cursorrules con reglas estipuladas, y proporciona el código organizando los cambios archivo por archivo con sus rutas exactas.'
        : 'NOTE FOR CURSOR AI: Provide a .cursorrules file and output code organized file by file with clear exact paths.';
      break;
    case 'v0':
      aiTuningNote = isEs 
        ? 'NOTA PARA V0: Enfócate en la estética UI/UX visualmente impresionante usando Shadcn UI y Tailwind CSS v4, interactividad de componentes y estados visuales elegantes.'
        : 'NOTE FOR V0: Focus heavily on visually stunning UI/UX using Shadcn UI & Tailwind CSS v4, rich micro-interactions and sleek visual states.';
      break;
    case 'claude':
    default:
      aiTuningNote = isEs
        ? 'NOTA PARA CLAUDE: Proporciona la implementación completa paso a paso con máxima atención al detalle, manejo de errores exhaustivo, datos de prueba iniciales (mock data) y explicaciones claras.'
        : 'NOTE FOR CLAUDE: Provide complete step-by-step implementation with maximum attention to detail, robust error handling, initial mock data, and clear code explanations.';
      break;
  }

  // Master Prompt Assembly
  const masterPrompt = isEs 
    ? `🎯 **INSTRUCCIÓN MAESTRA PARA DESARROLLO DE APLICACIÓN COMPLETA**

${systemPersona}

---

### 1. VISIÓN GENERAL DEL PROYECTO
- **Nombre de la Aplicación:** ${title}
- **Descripción:** ${description}
- **Público Objetivo:** ${targetAudience}
- **Nivel de Complejidad:** ${complexity === 'mvp' ? 'MVP Funcional (Rápido y enfocado)' : complexity === 'enterprise' ? 'Nivel Empresarial (Escalable y Robusto)' : 'Estándar Listo para Producción'}

---

### 2. STACK TECNOLÓGICO REQUERIDO
- **Frontend Framework:** ${stack.frontend}
- **Biblioteca UI & Estilos:** ${stack.uiLibrary}
- **Backend / BaaS:** ${stack.backend}
- **Base de Datos:** ${stack.database}
- **Autenticación:** ${stack.auth}
- **Pasarela de Pagos:** ${stack.payments}
- **Despliegue / Hosting:** ${stack.deploy}

---

### 3. FUNCIONALIDADES Y REQUERIMIENTOS CLAVE
${featureList.map(f => `- [x] ${f}`).join('\n')}

---

### 4. ARQUITECTURA DE ARCHIVOS Y ESTRUCTURA DEL PROYECTO
Organiza el proyecto siguiendo esta estructura limpia:

\`\`\`text
${folderStructure}
\`\`\`

---

### 5. MODELO DE DATOS E INTERFACES TYPESCRIPT
Crea y utiliza las siguientes definiciones de datos con TypeScript estricto:

\`\`\`typescript
${dbSchema}
\`\`\`

---

### 6. GUÍA DE ESTILO & UI/UX REQUERIDA
- **Paleta de Colores:** Slate / Dark Mode elegante con acentos vibrantes (Indigo/Violet/Emerald).
- **Diseño Responsive:** Mobile-first, adaptable desde 320px hasta monitores ultra-wide.
- **Componentes Interactivos:** Feedback visual en hover, loaders animados (skeletons), estados vacíos (empty states) atractivos con ilustraciones o iconos, y mensajes toast para acciones exitosas o errores.
- **Accesibilidad:** Cumplir con contraste adecuado y soporte de teclado básico.

---

### 7. PLAN DE EJECUCIÓN PASO A PASO
Comienza ejecutando la **Fase 1**, configurando la estructura base, componentes UI fundamentales y estado global. Luego procede con las fases subsiguientes.

${aiTuningNote}

---
¡Por favor, confirma que comprendes las instrucciones y comienza creando la estructura inicial del proyecto y la interfaz principal!`

    : `🎯 **MASTER PROMPT FOR COMPLETE APPLICATION DEVELOPMENT**

${systemPersona}

---

### 1. PROJECT OVERVIEW
- **Application Name:** ${title}
- **Description:** ${description}
- **Target Audience:** ${targetAudience}
- **Complexity Level:** ${complexity === 'mvp' ? 'MVP (Fast & Focused)' : complexity === 'enterprise' ? 'Enterprise Grade (Scalable & Robust)' : 'Production-Ready Standard'}

---

### 2. REQUIRED TECH STACK
- **Frontend Framework:** ${stack.frontend}
- **UI Library & Styling:** ${stack.uiLibrary}
- **Backend / BaaS:** ${stack.backend}
- **Database:** ${stack.database}
- **Authentication:** ${stack.auth}
- **Payments:** ${stack.payments}
- **Deployment:** ${stack.deploy}

---

### 3. KEY FEATURES & REQUIREMENTS
${featureList.map(f => `- [x] ${f}`).join('\n')}

---

### 4. FILE ARCHITECTURE & FOLDER STRUCTURE
Organize the codebase adhering to this clean modular layout:

\`\`\`text
${folderStructure}
\`\`\`

---

### 5. DATA MODEL & TYPESCRIPT INTERFACES
Define and implement strict TypeScript models:

\`\`\`typescript
${dbSchema}
\`\`\`

---

### 6. UI/UX & STYLING GUIDELINES
- **Color Scheme:** Dark Mode default with slate backdrop and modern gradient accents (Indigo/Violet/Emerald).
- **Responsive Layout:** Mobile-first approach fully adaptive across all screen sizes.
- **Micro-interactions:** Smooth hover effects, skeleton loader states, friendly empty states, and toast notifications for async events.

---

### 7. EXECUTION ROADMAP
Start by executing **Phase 1**: setting up core project scaffolding, UI components, and global application state. Proceed phase by phase.

${aiTuningNote}

---
Please confirm you understand these instructions and begin building the initial project structure and main interface!`;

  // Roadmap phases breakdown
  const roadmapPhases = [
    {
      phase: 'Fase 1',
      title: isEs ? 'Configuración de Proyecto, UI Base & Router' : 'Scaffolding, UI & Router Setup',
      promptText: isEs 
        ? `Por favor inicializa el proyecto "${title}" con ${stack.frontend} y ${stack.uiLibrary}. Configura los componentes UI base (Botones, Modales, Inputs, Cards, Navbar y Sidebar), los tipos de TypeScript y el diseño responsive principal con datos simulados (mock data).`
        : `Please initialize project "${title}" with ${stack.frontend} and ${stack.uiLibrary}. Build core UI primitives (Buttons, Modals, Inputs, Cards, Navbar, Sidebar), TypeScript types, and layout with initial mock data.`
    },
    {
      phase: 'Fase 2',
      title: isEs ? 'Módulos Funcionales, Estado Global & Filtros' : 'Core Features, Global State & Filtering',
      promptText: isEs
        ? `Implementa las pantallas principales de la aplicación "${title}", incluyendo la lista interactiva de elementos con filtros, búsqueda global, modales de creación/edición, y el estado global con React Context o Zustand.`
        : `Implement main application modules for "${title}", including item lists with live filters, search bar, creation/edit modals, and global state store with React Context or Zustand.`
    },
    {
      phase: 'Fase 3',
      title: isEs ? 'Autenticación, Integración Backend & Pagos' : 'Auth, Backend Integration & Payments',
      promptText: isEs
        ? `Integra la capa de autenticación con ${stack.auth}, la conexión con la base de datos ${stack.database} y la pasarela de pagos ${stack.payments}. Agrega middleware de protección de rutas y manejo de suscripciones.`
        : `Integrate authentication with ${stack.auth}, database layer with ${stack.database}, and payment gateway with ${stack.payments}. Add route guards and subscription state checking.`
    },
    {
      phase: 'Fase 4',
      title: isEs ? 'Refinamiento UI, Modo Oscuro, IA & Exportación' : 'UI Polish, Dark Mode, AI & Export Features',
      promptText: isEs
        ? `Finaliza la app añadiendo ${features.aiIntegration ? 'la integración de IA,' : ''} exportación a PDF/CSV, notificaciones Toast, animaciones fluidas, y asegúrate de que pase todas las comprobaciones de TypeScript sin errores.`
        : `Polish the application adding ${features.aiIntegration ? 'AI integrations,' : ''} PDF/CSV export, Toast notifications, smooth transitions, and verify complete TypeScript error-free compilation.`
    }
  ];

  const qualityChecklist = [
    isEs ? 'Definición de tipos de TypeScript sin "any"' : 'Strict TypeScript definitions with zero "any"',
    isEs ? 'Diseño 100% responsive (móvil, tablet, escritorio)' : '100% Mobile-first responsive layout',
    isEs ? 'Estados de carga (Skeletons) y estados vacíos (Empty States)' : 'Loading Skeletons & Empty state visuals',
    isEs ? 'Manejo de errores centralizado con mensajes claros' : 'Centralized error handling with user feedback',
    isEs ? 'Tema oscuro/claro persistente en localStorage' : 'Persistent Dark/Light mode theme',
    isEs ? 'Datos simulados (Mock Data) de alta calidad para pruebas inmediatas' : 'High quality initial mock data for instant testing'
  ];

  return {
    title,
    masterPrompt,
    systemPersona,
    architectureDetails: `${stack.frontend} + ${stack.uiLibrary} + ${stack.backend} + ${stack.database}`,
    folderStructure,
    dbSchema,
    roadmapPhases,
    qualityChecklist
  };
}
