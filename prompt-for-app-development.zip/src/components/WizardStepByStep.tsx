import React, { useState } from 'react';
import { 
  Sparkles, 
  ArrowRight, 
  ArrowLeft, 
  Check, 
  Plus, 
  X, 
  Terminal, 
  Layers, 
  Cpu, 
  SlidersHorizontal,
  Globe,
  ShoppingCart,
  BarChart3,
  Users,
  Smartphone,
  GraduationCap,
  Activity,
  Gamepad2,
  Wrench,
  Bot,
  Zap,
  Layout,
  GitPullRequest
} from 'lucide-react';
import { AppPromptConfig, Language, AppType, TargetAi } from '../types';
import { TECH_OPTIONS, TARGET_AI_OPTIONS, APP_TYPES } from '../data/techStackOptions';

interface WizardProps {
  language: Language;
  initialConfig?: AppPromptConfig;
  onGeneratePrompt: (config: AppPromptConfig) => void;
  onCancel?: () => void;
}

export const WizardStepByStep: React.FC<WizardProps> = ({
  language,
  initialConfig,
  onGeneratePrompt,
  onCancel
}) => {
  const [currentStep, setCurrentStep] = useState<number>(1);

  // Form State
  const [title, setTitle] = useState(initialConfig?.title || '');
  const [description, setDescription] = useState(initialConfig?.description || '');
  const [targetAudience, setTargetAudience] = useState(initialConfig?.targetAudience || '');
  const [appType, setAppType] = useState<AppType>(initialConfig?.appType || 'saas');
  const [complexity, setComplexity] = useState<'mvp' | 'standard' | 'enterprise'>(initialConfig?.complexity || 'standard');

  // Tech Stack State
  const [frontend, setFrontend] = useState(initialConfig?.stack.frontend || 'React + Vite (TypeScript)');
  const [uiLibrary, setUiLibrary] = useState(initialConfig?.stack.uiLibrary || 'Tailwind CSS v4');
  const [backend, setBackend] = useState(initialConfig?.stack.backend || 'Supabase (BaaS)');
  const [database, setDatabase] = useState(initialConfig?.stack.database || 'Supabase PostgreSQL');
  const [auth, setAuth] = useState(initialConfig?.stack.auth || 'Supabase Auth');
  const [payments, setPayments] = useState(initialConfig?.stack.payments || 'Stripe Payments / Subscriptions');
  const [deploy, setDeploy] = useState(initialConfig?.stack.deploy || 'Vercel');

  // Features State
  const [features, setFeatures] = useState(initialConfig?.features || {
    auth: true,
    darkMode: true,
    realtime: true,
    subscriptions: true,
    adminPanel: true,
    fileUpload: true,
    i18n: false,
    aiIntegration: true,
    searchFilter: true,
    exportPdfCsv: true,
    rbac: true,
    notifications: true,
    customFeatures: []
  });

  const [newCustomFeature, setNewCustomFeature] = useState('');

  // Target AI State
  const [targetAi, setTargetAi] = useState<TargetAi>(initialConfig?.targetAi || 'claude');
  const [outputLanguage, setOutputLanguage] = useState<Language>(language);

  // Quick fill samples
  const handleQuickPreset = (type: AppType) => {
    setAppType(type);
    if (type === 'saas') {
      setTitle('SaaS Platform for Team Productivity');
      setDescription('Plataforma web para que equipos gestionen proyectos, asignen tareas, cronometren tiempo y paguen suscripción.');
      setTargetAudience('Startups y empresas medianas');
    } else if (type === 'ecommerce') {
      setTitle('E-Commerce Store & Inventory Manager');
      setDescription('Tienda virtual con catálogo con filtros por categoría, carrito de compras persistente, checkout con Stripe y panel de ventas.');
      setTargetAudience('Compradores online y administradores');
    } else if (type === 'ai_app') {
      setTitle('AI Assistant & Document Scanner');
      setDescription('App de IA que permite subir archivos PDF, hacer preguntas RAG en chat y generar resúmenes con llamadas a API en streaming.');
      setTargetAudience('Estudiantes, investigadores y profesionales');
    } else if (type === 'dashboard') {
      setTitle('Business Intelligence & Executive Dashboard');
      setDescription('Dashboard interactivo de analíticas empresariales con indicadores KPI, gráficos en tiempo real y exportación de reportes PDF.');
      setTargetAudience('Directores de finanzas y gerentes de ventas');
    }
  };

  const handleAddCustomFeature = () => {
    if (!newCustomFeature.trim()) return;
    setFeatures(prev => ({
      ...prev,
      customFeatures: [...prev.customFeatures, newCustomFeature.trim()]
    }));
    setNewCustomFeature('');
  };

  const handleRemoveCustomFeature = (index: number) => {
    setFeatures(prev => ({
      ...prev,
      customFeatures: prev.customFeatures.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalConfig: AppPromptConfig = {
      title: title || (language === 'es' ? 'Mi Nueva Aplicación Web' : 'My New Web App'),
      description: description || (language === 'es' ? 'Una aplicación web moderna y escalable.' : 'A modern scalable web application.'),
      targetAudience: targetAudience || (language === 'es' ? 'Usuarios generales y administradores' : 'General users and administrators'),
      appType,
      complexity,
      stack: {
        frontend,
        uiLibrary,
        backend,
        database,
        auth,
        payments,
        deploy
      },
      features,
      targetAi,
      language: outputLanguage
    };

    onGeneratePrompt(finalConfig);
  };

  const getAppTypeIcon = (iconName: string) => {
    switch (iconName) {
      case 'Globe': return <Globe className="w-5 h-5 text-indigo-400" />;
      case 'ShoppingCart': return <ShoppingCart className="w-5 h-5 text-emerald-400" />;
      case 'BarChart3': return <BarChart3 className="w-5 h-5 text-amber-400" />;
      case 'Cpu': return <Cpu className="w-5 h-5 text-blue-400" />;
      case 'Users': return <Users className="w-5 h-5 text-rose-400" />;
      case 'Smartphone': return <Smartphone className="w-5 h-5 text-purple-400" />;
      case 'GraduationCap': return <GraduationCap className="w-5 h-5 text-teal-400" />;
      case 'Activity': return <Activity className="w-5 h-5 text-green-400" />;
      case 'Gamepad2': return <Gamepad2 className="w-5 h-5 text-pink-400" />;
      default: return <Wrench className="w-5 h-5 text-slate-400" />;
    }
  };

  const getAiIcon = (iconName: string) => {
    switch (iconName) {
      case 'Sparkles': return <Sparkles className="w-5 h-5 text-purple-400" />;
      case 'Bot': return <Bot className="w-5 h-5 text-emerald-400" />;
      case 'Code2': return <Terminal className="w-5 h-5 text-indigo-400" />;
      case 'Zap': return <Zap className="w-5 h-5 text-amber-400" />;
      case 'Layout': return <Layout className="w-5 h-5 text-blue-400" />;
      case 'Terminal': return <Terminal className="w-5 h-5 text-cyan-400" />;
      default: return <GitPullRequest className="w-5 h-5 text-rose-400" />;
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Step Indicator Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 mb-8 shadow-xl">
        <div className="flex items-center justify-between mb-6">
          <div>
            <span className="text-xs font-semibold text-indigo-400 uppercase tracking-wider">
              {language === 'es' ? 'Diseñador Interactivo' : 'Interactive Architect'}
            </span>
            <h2 className="text-2xl font-bold text-white">
              {language === 'es' ? 'Construir Prompt Maestro' : 'Build Master Development Prompt'}
            </h2>
          </div>
          {onCancel && (
            <button
              onClick={onCancel}
              className="px-3 py-1.5 text-xs text-slate-400 hover:text-white bg-slate-800 rounded-lg border border-slate-700 cursor-pointer"
            >
              {language === 'es' ? 'Cancelar' : 'Cancel'}
            </button>
          )}
        </div>

        {/* Wizard Steps */}
        <div className="grid grid-cols-4 gap-2">
          {[
            { num: 1, label: language === 'es' ? 'Concepto' : 'Concept', icon: SlidersHorizontal },
            { num: 2, label: language === 'es' ? 'Tech Stack' : 'Tech Stack', icon: Layers },
            { num: 3, label: language === 'es' ? 'Funciones' : 'Features', icon: Sparkles },
            { num: 4, label: language === 'es' ? 'Asistente IA' : 'AI Assistant', icon: Cpu },
          ].map((s) => {
            const StepIcon = s.icon;
            const isActive = currentStep === s.num;
            const isDone = currentStep > s.num;

            return (
              <button
                key={s.num}
                onClick={() => setCurrentStep(s.num)}
                className={`flex items-center gap-2.5 p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  isActive
                    ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300 font-semibold shadow-lg shadow-indigo-500/10'
                    : isDone
                    ? 'bg-slate-800/80 border-slate-700 text-slate-200'
                    : 'bg-slate-900/50 border-slate-800 text-slate-500 hover:text-slate-300'
                }`}
              >
                <div
                  className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold ${
                    isActive
                      ? 'bg-indigo-500 text-white'
                      : isDone
                      ? 'bg-emerald-500 text-slate-950'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {isDone ? <Check className="w-4 h-4" /> : <StepIcon className="w-3.5 h-3.5" />}
                </div>
                <div className="hidden sm:block text-xs">
                  <div className="font-medium">{s.label}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Form Content Steps */}
      <form onSubmit={handleSubmit} className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl">
        
        {/* STEP 1: App Concept & Type */}
        {currentStep === 1 && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-bold text-white mb-1">
                {language === 'es' ? '1. Concepto y Tipo de Aplicación' : '1. Concept & Application Type'}
              </h3>
              <p className="text-xs text-slate-400">
                {language === 'es' 
                  ? 'Define la idea básica de lo que deseas construir para estructurar el rol y persona de la IA'
                  : 'Define the core application goal to shape the AI persona'}
              </p>
            </div>

            {/* App Type Selector Grid */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                {language === 'es' ? 'Categoría de Aplicación' : 'Application Category'}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
                {APP_TYPES.map((type) => {
                  const selected = appType === type.id;
                  return (
                    <div
                      key={type.id}
                      onClick={() => handleQuickPreset(type.id)}
                      className={`p-3 rounded-xl border text-left cursor-pointer transition-all flex flex-col justify-between ${
                        selected
                          ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-md shadow-indigo-500/10'
                          : 'bg-slate-800/50 border-slate-800 hover:border-slate-700 text-slate-300'
                      }`}
                    >
                      <div className="mb-2">{getAppTypeIcon(type.icon)}</div>
                      <span className="text-xs font-semibold leading-tight">
                        {language === 'es' ? type.titleEs : type.titleEn}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Title Input */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                {language === 'es' ? 'Nombre o Título de la App' : 'App Title or Name'}
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder={language === 'es' ? 'Ej: Taskify SaaS, ShopEase Store, AI DocChat...' : 'e.g., Taskify SaaS, ShopEase Store...'}
                className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 text-sm"
              />
            </div>

            {/* Description Input */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                {language === 'es' ? 'Descripción del Objetivo Principal' : 'Primary Goal & Purpose'}
              </label>
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder={language === 'es' 
                  ? 'Describe qué hace tu app, qué problema resuelve y qué pantallas clave debe tener...'
                  : 'Describe what your app does, key problem solved, and main screen requirements...'}
                className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 text-sm"
              />
            </div>

            {/* Target Audience & Complexity */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  {language === 'es' ? 'Público Objetivo / Usuarios' : 'Target Audience / Users'}
                </label>
                <input
                  type="text"
                  value={targetAudience}
                  onChange={(e) => setTargetAudience(e.target.value)}
                  placeholder={language === 'es' ? 'Ej: Equipos remotos, Médicos, Estudiantes' : 'e.g., Remote teams, Doctors, Students'}
                  className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  {language === 'es' ? 'Nivel de Arquitectura' : 'Architecture Scope'}
                </label>
                <select
                  value={complexity}
                  onChange={(e) => setComplexity(e.target.value as any)}
                  className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-indigo-500 text-sm"
                >
                  <option value="mvp">{language === 'es' ? 'MVP Funcional (Rápido y enfocado)' : 'MVP (Fast & Light)'}</option>
                  <option value="standard">{language === 'es' ? 'Estándar Listo para Producción' : 'Standard Production-Ready'}</option>
                  <option value="enterprise">{language === 'es' ? 'Nivel Empresarial Escalable' : 'Enterprise Scalable Grade'}</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: Tech Stack Selection */}
        {currentStep === 2 && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-bold text-white mb-1">
                {language === 'es' ? '2. Selección del Stack Tecnológico' : '2. Tech Stack Specification'}
              </h3>
              <p className="text-xs text-slate-400">
                {language === 'es'
                  ? 'Elige tus tecnologías preferidas para que la IA configure los paquetes e imports correctos'
                  : 'Choose your preferred stack for accurate imports and package configurations'}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {/* Frontend */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Frontend Framework
                </label>
                <select
                  value={frontend}
                  onChange={(e) => setFrontend(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-indigo-500 text-sm"
                >
                  {TECH_OPTIONS.frontend.map(opt => (
                    <option key={opt.id} value={opt.label}>{opt.label}</option>
                  ))}
                </select>
              </div>

              {/* UI Library */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  UI & Styling Library
                </label>
                <select
                  value={uiLibrary}
                  onChange={(e) => setUiLibrary(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-indigo-500 text-sm"
                >
                  {TECH_OPTIONS.uiLibrary.map(opt => (
                    <option key={opt.id} value={opt.label}>{opt.label}</option>
                  ))}
                </select>
              </div>

              {/* Backend */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Backend / BaaS Layer
                </label>
                <select
                  value={backend}
                  onChange={(e) => setBackend(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-indigo-500 text-sm"
                >
                  {TECH_OPTIONS.backend.map(opt => (
                    <option key={opt.id} value={opt.label}>{opt.label}</option>
                  ))}
                </select>
              </div>

              {/* Database */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Database & ORM
                </label>
                <select
                  value={database}
                  onChange={(e) => setDatabase(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-indigo-500 text-sm"
                >
                  {TECH_OPTIONS.database.map(opt => (
                    <option key={opt.id} value={opt.label}>{opt.label}</option>
                  ))}
                </select>
              </div>

              {/* Authentication */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Authentication Strategy
                </label>
                <select
                  value={auth}
                  onChange={(e) => setAuth(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-indigo-500 text-sm"
                >
                  {TECH_OPTIONS.auth.map(opt => (
                    <option key={opt.id} value={opt.label}>{opt.label}</option>
                  ))}
                </select>
              </div>

              {/* Payments */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Payments / Billing
                </label>
                <select
                  value={payments}
                  onChange={(e) => setPayments(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-indigo-500 text-sm"
                >
                  {TECH_OPTIONS.payments.map(opt => (
                    <option key={opt.id} value={opt.label}>{opt.label}</option>
                  ))}
                </select>
              </div>

              {/* Hosting / Deployment */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Deployment Platform
                </label>
                <select
                  value={deploy}
                  onChange={(e) => setDeploy(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-indigo-500 text-sm"
                >
                  {TECH_OPTIONS.deploy.map(opt => (
                    <option key={opt.id} value={opt.label}>{opt.label}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        )}

        {/* STEP 3: Features & Capabilities */}
        {currentStep === 3 && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-bold text-white mb-1">
                {language === 'es' ? '3. Módulos y Funcionalidades' : '3. Key Features & Modules'}
              </h3>
              <p className="text-xs text-slate-400">
                {language === 'es'
                  ? 'Marca los componentes clave que el prompt le exigirá construir a la IA'
                  : 'Check the key modules that the prompt will instruct the AI to build'}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {[
                { id: 'auth', label: language === 'es' ? 'Autenticación & Usuarios' : 'User Auth & Sessions' },
                { id: 'darkMode', label: language === 'es' ? 'Modo Oscuro/Claro Toggle' : 'Dark/Light Theme' },
                { id: 'realtime', label: language === 'es' ? 'Actualizaciones Realtime' : 'Realtime WebSockets' },
                { id: 'subscriptions', label: language === 'es' ? 'Planes & Suscripciones' : 'Plans & Subscriptions' },
                { id: 'adminPanel', label: language === 'es' ? 'Panel Admin & Métricas' : 'Admin Panel & Metrics' },
                { id: 'fileUpload', label: language === 'es' ? 'Subida de Archivos/Imágenes' : 'File & Image Uploads' },
                { id: 'i18n', label: language === 'es' ? 'Multi-idioma / i18n' : 'Multi-language i18n' },
                { id: 'aiIntegration', label: language === 'es' ? 'Integración con IA / LLM' : 'AI / LLM Integration' },
                { id: 'searchFilter', label: language === 'es' ? 'Búsqueda & Filtros Avanzados' : 'Advanced Search & Filter' },
                { id: 'exportPdfCsv', label: language === 'es' ? 'Exportar a PDF y CSV' : 'PDF & CSV Exports' },
                { id: 'rbac', label: language === 'es' ? 'Control de Roles (RBAC)' : 'Role-Based Access (RBAC)' },
                { id: 'notifications', label: language === 'es' ? 'Sistema Notificaciones Toast' : 'Toast Notifications' }
              ].map((feat) => {
                const key = feat.id as keyof typeof features;
                const isChecked = Boolean(features[key]);
                return (
                  <label
                    key={feat.id}
                    className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                      isChecked
                        ? 'bg-indigo-600/15 border-indigo-500/80 text-white'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={(e) => setFeatures({ ...features, [key]: e.target.checked })}
                      className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 bg-slate-900 border-slate-700"
                    />
                    <span className="text-xs font-medium">{feat.label}</span>
                  </label>
                );
              })}
            </div>

            {/* Custom Extra Features Input */}
            <div className="pt-4 border-t border-slate-800">
              <label className="block text-xs font-medium text-slate-300 mb-2">
                {language === 'es' ? 'Agregar Requerimientos Personalizados Especiales' : 'Add Special Custom Requirements'}
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newCustomFeature}
                  onChange={(e) => setNewCustomFeature(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddCustomFeature();
                    }
                  }}
                  placeholder={language === 'es' ? 'Ej: Exportar resumen en ZIP, Calculadora de impuestos...' : 'e.g. Export ZIP bundle, tax calculator...'}
                  className="flex-1 px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 text-xs focus:outline-none focus:border-indigo-500"
                />
                <button
                  type="button"
                  onClick={handleAddCustomFeature}
                  className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>{language === 'es' ? 'Añadir' : 'Add'}</span>
                </button>
              </div>

              {/* Added Custom Features Tag List */}
              {features.customFeatures.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-3">
                  {features.customFeatures.map((cf, idx) => (
                    <span
                      key={idx}
                      className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 rounded-lg text-xs"
                    >
                      <span>{cf}</span>
                      <X
                        className="w-3.5 h-3.5 cursor-pointer hover:text-red-400"
                        onClick={() => handleRemoveCustomFeature(idx)}
                      />
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* STEP 4: Target AI Assistant & Language */}
        {currentStep === 4 && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-bold text-white mb-1">
                {language === 'es' ? '4. Asistente IA de Destino y Formato' : '4. Target AI & Output Preferences'}
              </h3>
              <p className="text-xs text-slate-400">
                {language === 'es'
                  ? 'Optimizaremos la sintaxis del prompt maestro según la herramienta de IA que vayas a usar'
                  : 'We tailor the prompt syntax specifically for your target AI coding tool'}
              </p>
            </div>

            {/* AI Assistant Selector Grid */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                {language === 'es' ? 'Herramienta de IA que Usarás' : 'Target AI Assistant / IDE'}
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {TARGET_AI_OPTIONS.map((aiOpt) => {
                  const isSelected = targetAi === aiOpt.id;
                  return (
                    <div
                      key={aiOpt.id}
                      onClick={() => setTargetAi(aiOpt.id)}
                      className={`p-3.5 rounded-xl border text-left cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-lg shadow-indigo-500/10'
                          : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-300'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 mb-1.5">
                        {getAiIcon(aiOpt.icon)}
                        <span className="font-bold text-xs">{aiOpt.name}</span>
                      </div>
                      <p className="text-[11px] text-slate-400 leading-tight">
                        {aiOpt.desc}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Prompt Language Selector */}
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <label className="block text-xs font-semibold text-white mb-1">
                  {language === 'es' ? 'Idioma del Prompt Generado' : 'Generated Prompt Language'}
                </label>
                <p className="text-xs text-slate-400">
                  {language === 'es'
                    ? '¿En qué idioma quieres recibir las instrucciones maestra?'
                    : 'Select output prompt language format'}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setOutputLanguage('es')}
                  className={`px-4 py-2 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                    outputLanguage === 'es'
                      ? 'bg-indigo-600 border-indigo-500 text-white'
                      : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  Español (ES)
                </button>
                <button
                  type="button"
                  onClick={() => setOutputLanguage('en')}
                  className={`px-4 py-2 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                    outputLanguage === 'en'
                      ? 'bg-indigo-600 border-indigo-500 text-white'
                      : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  English (EN)
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Wizard Footer Navigation */}
        <div className="mt-8 pt-6 border-t border-slate-800 flex items-center justify-between">
          {currentStep > 1 ? (
            <button
              type="button"
              onClick={() => setCurrentStep(prev => prev - 1)}
              className="flex items-center gap-2 px-4 py-2.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl transition-all cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>{language === 'es' ? 'Anterior' : 'Back'}</span>
            </button>
          ) : <div />}

          {currentStep < 4 ? (
            <button
              type="button"
              onClick={() => setCurrentStep(prev => prev + 1)}
              className="flex items-center gap-2 px-5 py-2.5 text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl transition-all cursor-pointer shadow-md shadow-indigo-600/20"
            >
              <span>{language === 'es' ? 'Siguiente' : 'Next Step'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-3 text-sm font-bold bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 rounded-xl transition-all cursor-pointer shadow-lg shadow-emerald-500/25 active:scale-95"
            >
              <Sparkles className="w-4 h-4" />
              <span>{language === 'es' ? '¡Generar Prompt Maestro!' : 'Generate Master Prompt!'}</span>
            </button>
          )}
        </div>
      </form>
    </div>
  );
};
