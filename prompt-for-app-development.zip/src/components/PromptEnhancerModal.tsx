import React, { useState } from 'react';
import { X, Wand2, Sparkles, ArrowRight, Check } from 'lucide-react';
import { Language, AppPromptConfig, AppType } from '../types';

interface EnhancerProps {
  language: Language;
  isOpen: boolean;
  onClose: () => void;
  onApplyEnhancement: (config: Partial<AppPromptConfig>) => void;
}

export const PromptEnhancerModal: React.FC<EnhancerProps> = ({
  language,
  isOpen,
  onClose,
  onApplyEnhancement
}) => {
  const [roughIdea, setRoughIdea] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [enhancedResult, setEnhancedResult] = useState<{
    title: string;
    description: string;
    targetAudience: string;
    appType: AppType;
    recommendedFeatures: string[];
  } | null>(null);

  if (!isOpen) return null;

  const handleEnhance = () => {
    if (!roughIdea.trim()) return;
    setIsProcessing(true);

    setTimeout(() => {
      // Intelligent parser mock heuristic based on keywords
      const input = roughIdea.toLowerCase();
      let appType: AppType = 'saas';
      let title = language === 'es' ? 'Plataforma Digital Inteligente' : 'Smart Digital Platform';
      let targetAudience = language === 'es' ? 'Usuarios finales y administradores' : 'End users and admins';
      let recommendedFeatures = [
        language === 'es' ? 'Registro y login con perfil' : 'User auth with profile',
        language === 'es' ? 'Panel de control con métricas' : 'Metrics dashboard',
        language === 'es' ? 'Notificaciones en tiempo real' : 'Realtime notifications'
      ];

      if (input.includes('tienda') || input.includes('compra') || input.includes('vender') || input.includes('producto') || input.includes('e-commerce') || input.includes('store')) {
        appType = 'ecommerce';
        title = language === 'es' ? 'Tienda Online & Gestión de Pedidos' : 'E-Commerce Store & Order Hub';
        targetAudience = language === 'es' ? 'Clientes compradores y equipo de logística' : 'Buyers and logistics staff';
        recommendedFeatures.push(
          language === 'es' ? 'Carrito de compras con checkout' : 'Cart with Stripe checkout',
          language === 'es' ? 'Filtros dinámicos por categoría' : 'Dynamic category filters'
        );
      } else if (input.includes('médico') || input.includes('salud') || input.includes('turno') || input.includes('gym') || input.includes('caloría') || input.includes('fitness')) {
        appType = 'health';
        title = language === 'es' ? 'Plataforma de Salud & Gestión de Citas' : 'Health & Booking Management System';
        targetAudience = language === 'es' ? 'Pacientes, médicos y administradores de clínica' : 'Patients, practitioners, and clinic staff';
        recommendedFeatures.push(
          language === 'es' ? 'Calendario interactivo de agendamiento' : 'Interactive booking calendar',
          language === 'es' ? 'Historial clínico y recordatorios SMS/Email' : 'Medical history & reminders'
        );
      } else if (input.includes('ia') || input.includes('gpt') || input.includes('claude') || input.includes('chat') || input.includes('bot') || input.includes('pdf')) {
        appType = 'ai_app';
        title = language === 'es' ? 'Asistente de IA Studio & RAG' : 'AI Assistant & Content Studio';
        targetAudience = language === 'es' ? 'Creadores de contenido y profesionales' : 'Content creators & professionals';
        recommendedFeatures.push(
          language === 'es' ? 'Streaming de respuesta SSE' : 'SSE realtime streaming',
          language === 'es' ? 'Lector y análisis de archivos PDF' : 'RAG PDF document scanner'
        );
      } else if (input.includes('cliente') || input.includes('venta') || input.includes('crm') || input.includes('lead') || input.includes('contacto')) {
        appType = 'crm';
        title = language === 'es' ? 'Smart CRM & Pipeline Comercial' : 'Smart Sales CRM & Pipeline';
        targetAudience = language === 'es' ? 'Equipos de venta y gerentes comerciales' : 'Sales reps & commercial leads';
        recommendedFeatures.push(
          language === 'es' ? 'Tablero Kanban Drag & Drop' : 'Kanban Drag & Drop Board',
          language === 'es' ? 'Registro de llamadas y seguimiento' : 'Activity logs & reminders'
        );
      } else if (input.includes('curso') || input.includes('clase') || input.includes('estudiante') || input.includes('aprender') || input.includes('educación')) {
        appType = 'edtech';
        title = language === 'es' ? 'Academia Virtual & Lecciones en Video' : 'Virtual Academy & Course Platform';
        targetAudience = language === 'es' ? 'Estudiantes y profesores' : 'Students and instructors';
        recommendedFeatures.push(
          language === 'es' ? 'Reproductor de video con barra de progreso' : 'Video player with progress bar',
          language === 'es' ? 'Quizzes interactivos y certificados PDF' : 'Interactive quizzes & certificates'
        );
      }

      setEnhancedResult({
        title,
        description: roughIdea,
        targetAudience,
        appType,
        recommendedFeatures
      });
      setIsProcessing(false);
    }, 1000);
  };

  const handleApply = () => {
    if (!enhancedResult) return;
    onApplyEnhancement({
      title: enhancedResult.title,
      description: enhancedResult.description,
      targetAudience: enhancedResult.targetAudience,
      appType: enhancedResult.appType
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-purple-500/20 border border-purple-500/40 flex items-center justify-center">
              <Wand2 className="w-4 h-4 text-purple-400" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">
                {language === 'es' ? 'Generador IA de Idea a Prompt' : 'AI Idea-to-Prompt Enhancer'}
              </h3>
              <p className="text-xs text-slate-400">
                {language === 'es' 
                  ? 'Escribe tu idea en 1 o 2 oraciones y la IA estructurará la visión completa'
                  : 'Type a brief idea and AI will expand it into structured requirements'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-lg cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Text Input */}
        <div className="py-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">
              {language === 'es' ? 'Escribe tu idea (ej: "Quiero una app para un taller mecánico donde el cliente agende turnos"):' : 'Type your idea:'}
            </label>
            <textarea
              rows={3}
              value={roughIdea}
              onChange={(e) => setRoughIdea(e.target.value)}
              placeholder={language === 'es' 
                ? 'Ej: Quiero una app de gestión de finanzas personales donde registre gastos, vea gráficos y me dé consejos de ahorro con IA...' 
                : 'e.g., I want a personal finance app where I log expenses, see charts and get AI savings advice...'}
              className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 text-xs placeholder-slate-500 focus:outline-none focus:border-purple-500"
            />
          </div>

          <button
            onClick={handleEnhance}
            disabled={!roughIdea.trim() || isProcessing}
            className="w-full py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <Sparkles className="w-4 h-4 text-purple-200" />
            <span>
              {isProcessing 
                ? (language === 'es' ? 'Analizando Idea...' : 'Analyzing Idea...') 
                : (language === 'es' ? 'Transformar con IA' : 'Enhance Idea with AI')}
            </span>
          </button>

          {/* Enhanced Result Box */}
          {enhancedResult && (
            <div className="p-4 bg-slate-950 border border-purple-500/30 rounded-xl space-y-3 mt-4 animate-fadeIn">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-purple-300 flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  {language === 'es' ? 'Idea Expandida Exitosamente' : 'Expanded Concept Proposal'}
                </span>
                <span className="text-[10px] px-2 py-0.5 bg-purple-500/20 text-purple-300 rounded font-semibold uppercase">
                  {enhancedResult.appType}
                </span>
              </div>

              <div>
                <span className="text-[11px] text-slate-400">Título Propuesto:</span>
                <p className="text-xs font-bold text-white">{enhancedResult.title}</p>
              </div>

              <div>
                <span className="text-[11px] text-slate-400">Público Objetivo:</span>
                <p className="text-xs text-slate-300">{enhancedResult.targetAudience}</p>
              </div>

              <div>
                <span className="text-[11px] text-slate-400">Funcionalidades Sugeridas:</span>
                <ul className="text-xs text-slate-300 space-y-1 mt-1">
                  {enhancedResult.recommendedFeatures.map((rf, idx) => (
                    <li key={idx} className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                      <span>{rf}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <button
                onClick={handleApply}
                className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer mt-2"
              >
                <span>{language === 'es' ? 'Aplicar al Diseñador de Prompts' : 'Apply to Prompt Builder'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
