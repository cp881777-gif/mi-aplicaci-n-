import React, { useState } from 'react';
import { X, Bookmark, Trash2, ArrowRight, Search, Terminal } from 'lucide-react';
import { AppPromptConfig, Language } from '../types';

interface SavedPromptsProps {
  language: Language;
  isOpen: boolean;
  onClose: () => void;
  savedPrompts: AppPromptConfig[];
  onSelectSavedPrompt: (config: AppPromptConfig) => void;
  onDeleteSavedPrompt: (id: string) => void;
}

export const SavedPromptsModal: React.FC<SavedPromptsProps> = ({
  language,
  isOpen,
  onClose,
  savedPrompts,
  onSelectSavedPrompt,
  onDeleteSavedPrompt
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  if (!isOpen) return null;

  const filtered = savedPrompts.filter(p => 
    p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 overflow-hidden flex flex-col max-h-[85vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Bookmark className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-white text-base">
              {language === 'es' ? 'Prompts Guardados' : 'Saved Prompts Library'}
            </h3>
            <span className="text-xs px-2 py-0.5 bg-amber-500/20 text-amber-300 rounded-full font-bold">
              {savedPrompts.length}
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-lg cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search Filter Bar */}
        <div className="py-4">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={language === 'es' ? 'Buscar prompt por nombre...' : 'Search saved prompts...'}
              className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-amber-500"
            />
          </div>
        </div>

        {/* List Content */}
        <div className="overflow-y-auto flex-1 space-y-3 pr-1">
          {filtered.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              <Terminal className="w-8 h-8 mx-auto mb-2 text-slate-600" />
              <p className="text-xs">
                {language === 'es' ? 'No hay prompts guardados todavía.' : 'No saved prompts yet.'}
              </p>
            </div>
          ) : (
            filtered.map((item) => (
              <div
                key={item.id}
                className="bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-xl p-4 transition-all flex items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-sm text-white">{item.title}</h4>
                    <span className="text-[10px] px-2 py-0.5 bg-indigo-500/10 text-indigo-300 rounded border border-indigo-500/20 uppercase font-semibold">
                      {item.appType}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 line-clamp-1">{item.description}</p>
                  <p className="text-[10px] text-slate-500">
                    {item.stack.frontend} • {item.targetAi.toUpperCase()}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => {
                      onSelectSavedPrompt(item);
                      onClose();
                    }}
                    className="p-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    <span>{language === 'es' ? 'Ver' : 'Open'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => item.id && onDeleteSavedPrompt(item.id)}
                    className="p-2 bg-slate-900 hover:bg-red-500/20 text-slate-400 hover:text-red-400 border border-slate-800 rounded-lg transition-colors cursor-pointer"
                    title={language === 'es' ? 'Eliminar' : 'Delete'}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

      </div>
    </div>
  );
};
