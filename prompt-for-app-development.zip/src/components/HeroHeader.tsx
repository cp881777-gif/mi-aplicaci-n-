import React from 'react';
import { Sparkles, Terminal, Wand2, ArrowRight } from 'lucide-react';
import { Language } from '../types';

interface HeroHeaderProps {
  language: Language;
  onStartCustomWizard: () => void;
  onOpenEnhancerModal: () => void;
}

export const HeroHeader: React.FC<HeroHeaderProps> = ({
  language,
  onStartCustomWizard,
  onOpenEnhancerModal
}) => {
  return (
    <div className="relative overflow-hidden pt-8 pb-10 px-4 sm:px-6 lg:px-8 text-center">
      {/* Background glow effects */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-indigo-600/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-0 right-1/4 w-72 h-72 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative max-w-4xl mx-auto">
        {/* Top Tag */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-medium mb-6 backdrop-blur-sm shadow-inner">
          <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
          <span>
            {language === 'es'
              ? 'Generador de Prompts Maestros para Claude, ChatGPT, Cursor & Bolt.new'
              : 'Master Software Engineering Prompt Builder for Claude, ChatGPT, Cursor & Bolt'}
          </span>
        </div>

        {/* Headline */}
        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight mb-4">
          {language === 'es' ? (
            <>
              El Prompt Perfecto para <br />
              <span className="bg-gradient-to-r from-indigo-400 via-purple-300 to-pink-400 bg-clip-text text-transparent">
                Desarrollar Tu Aplicación
              </span>
            </>
          ) : (
            <>
              The Master Prompt to Build <br />
              <span className="bg-gradient-to-r from-indigo-400 via-purple-300 to-pink-400 bg-clip-text text-transparent">
                Your Full-Stack Application
              </span>
            </>
          )}
        </h1>

        {/* Subtitle */}
        <p className="max-w-2xl mx-auto text-base sm:text-lg text-slate-300 mb-8 leading-relaxed">
          {language === 'es'
            ? 'Selecciona tu tipo de app, stack técnico y requerimientos. Generamos automáticamente prompts estructurados con arquitectura, esquema DB, estructura de archivos y fases paso a paso listos para copiar.'
            : 'Select your app type, tech stack, and specifications. We instantly generate bulletproof structured prompts complete with architecture, DB schema, file layout, and phase-by-phase roadmaps.'}
        </p>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-4">
          <button
            onClick={onStartCustomWizard}
            className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-semibold text-sm shadow-lg shadow-indigo-500/25 transition-all hover:scale-[1.02] cursor-pointer active:scale-95"
          >
            <Terminal className="w-4 h-4" />
            <span>
              {language === 'es' ? 'Diseñar Prompt a Medida' : 'Design Custom Prompt'}
            </span>
            <ArrowRight className="w-4 h-4 ml-1" />
          </button>

          <button
            onClick={onOpenEnhancerModal}
            className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 border border-slate-700 font-medium text-sm transition-all hover:scale-[1.02] cursor-pointer"
          >
            <Wand2 className="w-4 h-4 text-purple-400" />
            <span>
              {language === 'es' ? 'Transformar Idea Corta con IA' : 'Transform Brief Idea with AI'}
            </span>
          </button>
        </div>

        {/* Quick Tech Badges */}
        <div className="mt-8 pt-6 border-t border-slate-800/60 flex flex-wrap items-center justify-center gap-3 text-xs text-slate-400">
          <span className="text-slate-500 font-medium">Compatible con:</span>
          <span className="px-2.5 py-1 bg-slate-900/80 rounded-md border border-slate-800 text-slate-300">Claude 3.7 / Sonnet</span>
          <span className="px-2.5 py-1 bg-slate-900/80 rounded-md border border-slate-800 text-slate-300">ChatGPT GPT-4o</span>
          <span className="px-2.5 py-1 bg-slate-900/80 rounded-md border border-slate-800 text-slate-300">Cursor AI</span>
          <span className="px-2.5 py-1 bg-slate-900/80 rounded-md border border-slate-800 text-slate-300">Bolt.new</span>
          <span className="px-2.5 py-1 bg-slate-900/80 rounded-md border border-slate-800 text-slate-300">v0 Vercel</span>
          <span className="px-2.5 py-1 bg-slate-900/80 rounded-md border border-slate-800 text-slate-300">Windsurf</span>
        </div>
      </div>
    </div>
  );
};
