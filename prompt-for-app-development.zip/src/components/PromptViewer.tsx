import React, { useState } from 'react';
import { 
  Copy, 
  Check, 
  Download, 
  Play, 
  Bookmark, 
  Terminal, 
  FolderTree, 
  Database, 
  Layers, 
  CheckSquare, 
  Edit3, 
  RotateCcw,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { GeneratedPromptResult, AppPromptConfig, Language } from '../types';

interface PromptViewerProps {
  language: Language;
  promptResult: GeneratedPromptResult;
  config: AppPromptConfig;
  onSavePrompt: (config: AppPromptConfig) => void;
  isSaved: boolean;
  onTestInSimulator: () => void;
  onResetToWizard: () => void;
}

export const PromptViewer: React.FC<PromptViewerProps> = ({
  language,
  promptResult,
  config,
  onSavePrompt,
  isSaved,
  onTestInSimulator,
  onResetToWizard
}) => {
  const [activeTab, setActiveTab] = useState<'master' | 'phases' | 'structure' | 'db' | 'checklist'>('master');
  const [copiedTab, setCopiedTab] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editedPrompt, setEditedPrompt] = useState(promptResult.masterPrompt);

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedTab(label);
    confetti({
      particleCount: 40,
      spread: 60,
      origin: { y: 0.8 }
    });
    setTimeout(() => setCopiedTab(null), 2000);
  };

  const handleDownloadMarkdown = () => {
    const filename = `${config.title.toLowerCase().replace(/[^a-z0-0]/g, '-')}-prompt.md`;
    const element = document.createElement('a');
    const file = new Blob([editedPrompt], { type: 'text/markdown' });
    element.href = URL.createObjectURL(file);
    element.download = filename;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      
      {/* Top Banner & Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 mb-6 shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                {language === 'es' ? 'PROMPT COMPLETO LISTO' : 'MASTER PROMPT READY'}
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-slate-800 text-slate-300 border border-slate-700">
                {config.targetAi.toUpperCase()}
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                {config.stack.frontend.split(' ')[0]}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
              {config.title}
            </h1>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              {config.description}
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => handleCopy(editedPrompt, 'master')}
              className="flex items-center gap-1.5 px-4 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-semibold text-xs rounded-xl shadow-lg shadow-indigo-600/25 transition-all cursor-pointer active:scale-95"
            >
              {copiedTab === 'master' ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
              <span>
                {copiedTab === 'master' 
                  ? (language === 'es' ? '¡Copiado!' : 'Copied!') 
                  : (language === 'es' ? 'Copiar Prompt Maestro' : 'Copy Master Prompt')}
              </span>
            </button>

            <button
              onClick={onTestInSimulator}
              className="flex items-center gap-1.5 px-3.5 py-2.5 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 text-xs font-semibold rounded-xl transition-all cursor-pointer"
              title={language === 'es' ? 'Probar respuesta en simulador de IA' : 'Test run prompt in AI Sandbox'}
            >
              <Play className="w-4 h-4 text-emerald-400 fill-emerald-400" />
              <span className="hidden sm:inline">
                {language === 'es' ? 'Probar en IA Sandbox' : 'Test in Sandbox'}
              </span>
            </button>

            <button
              onClick={() => onSavePrompt(config)}
              className={`flex items-center gap-1.5 px-3 py-2.5 text-xs font-medium rounded-xl border transition-all cursor-pointer ${
                isSaved
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
              }`}
            >
              <Bookmark className="w-4 h-4 text-amber-400" />
              <span>{isSaved ? (language === 'es' ? 'Guardado' : 'Saved') : (language === 'es' ? 'Guardar' : 'Save')}</span>
            </button>

            <button
              onClick={handleDownloadMarkdown}
              className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-xl transition-all cursor-pointer"
              title={language === 'es' ? 'Descargar como Markdown (.md)' : 'Download Markdown (.md)'}
            >
              <Download className="w-4 h-4" />
            </button>

            <button
              onClick={onResetToWizard}
              className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-xl transition-all cursor-pointer"
              title={language === 'es' ? 'Crear otro prompt' : 'Create another prompt'}
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Stack Highlights pills */}
        <div className="mt-5 pt-4 border-t border-slate-800/80 flex flex-wrap gap-2 text-xs text-slate-300">
          <span className="text-slate-500 font-medium">Stack:</span>
          <span className="px-2 py-0.5 bg-slate-950 rounded border border-slate-800">{config.stack.frontend}</span>
          <span className="px-2 py-0.5 bg-slate-950 rounded border border-slate-800">{config.stack.uiLibrary}</span>
          <span className="px-2 py-0.5 bg-slate-950 rounded border border-slate-800">{config.stack.backend}</span>
          <span className="px-2 py-0.5 bg-slate-950 rounded border border-slate-800">{config.stack.database}</span>
          <span className="px-2 py-0.5 bg-slate-950 rounded border border-slate-800">{config.stack.auth}</span>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex border-b border-slate-800 mb-6 overflow-x-auto gap-2">
        {[
          { id: 'master', label: language === 'es' ? 'Prompt Maestro' : 'Master Prompt', icon: Terminal },
          { id: 'phases', label: language === 'es' ? 'Fases Paso a Paso' : 'Step-by-Step Roadmaps', icon: Layers },
          { id: 'structure', label: language === 'es' ? 'Estructura Archivos' : 'Folder Architecture', icon: FolderTree },
          { id: 'db', label: language === 'es' ? 'Esquema DB / Modelos' : 'DB Schema & Types', icon: Database },
          { id: 'checklist', label: language === 'es' ? 'Checklist Calidad' : 'Quality Checklist', icon: CheckSquare }
        ].map((tab) => {
          const TabIcon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                isActive
                  ? 'border-indigo-500 text-indigo-300 bg-indigo-500/10 rounded-t-lg'
                  : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
              }`}
            >
              <TabIcon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: MASTER PROMPT */}
      {activeTab === 'master' && (
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-6 shadow-xl relative">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2 text-xs font-medium text-slate-400">
              <Terminal className="w-4 h-4 text-indigo-400" />
              <span>
                {language === 'es' ? 'Instrucciones Completas para Copiar y Pegar en la IA' : 'Complete Instructions to Paste into AI Assistant'}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsEditing(!isEditing)}
                className="flex items-center gap-1.5 px-3 py-1 text-xs bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 rounded-lg transition-colors cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>{isEditing ? (language === 'es' ? 'Guardar Cambios' : 'Save Changes') : (language === 'es' ? 'Editar' : 'Edit')}</span>
              </button>

              <button
                onClick={() => handleCopy(editedPrompt, 'master_code')}
                className="flex items-center gap-1.5 px-3 py-1 text-xs bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-colors cursor-pointer font-semibold"
              >
                {copiedTab === 'master_code' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedTab === 'master_code' ? (language === 'es' ? 'Copiado' : 'Copied') : (language === 'es' ? 'Copiar' : 'Copy')}</span>
              </button>
            </div>
          </div>

          {isEditing ? (
            <textarea
              rows={22}
              value={editedPrompt}
              onChange={(e) => setEditedPrompt(e.target.value)}
              className="w-full font-mono text-xs p-4 bg-slate-900 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-indigo-500 leading-relaxed"
            />
          ) : (
            <pre className="font-mono text-xs p-5 bg-slate-900/90 rounded-xl text-slate-200 overflow-x-auto leading-relaxed whitespace-pre-wrap selection:bg-indigo-500 selection:text-white border border-slate-800/80">
              {editedPrompt}
            </pre>
          )}
        </div>
      )}

      {/* TAB 2: STEP BY STEP ROADMAP PHASES */}
      {activeTab === 'phases' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 text-xs text-slate-300">
            <p className="font-semibold text-white mb-1 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              {language === 'es' ? 'Prompts Divididos por Fases de Desarrollo' : 'Phase-by-Phase Development Prompts'}
            </p>
            <p className="text-slate-400">
              {language === 'es'
                ? 'Si prefieres construir tu aplicación paso a paso sin saturar la memoria de contexto de la IA, copia estas instrucciones en secuencia:'
                : 'If you prefer incremental development, feed these individual phase prompts into your AI tool sequentially:'}
            </p>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {promptResult.roadmapPhases.map((ph, idx) => (
              <div key={idx} className="bg-slate-950 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition-all">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-md bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-bold text-xs flex items-center justify-center">
                      {idx + 1}
                    </span>
                    <h3 className="font-bold text-sm text-white">{ph.phase}: {ph.title}</h3>
                  </div>

                  <button
                    onClick={() => handleCopy(ph.promptText, `phase_${idx}`)}
                    className="flex items-center gap-1 px-3 py-1 bg-slate-900 hover:bg-indigo-600 text-slate-300 hover:text-white rounded-lg text-xs font-medium border border-slate-800 transition-colors cursor-pointer"
                  >
                    {copiedTab === `phase_${idx}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedTab === `phase_${idx}` ? (language === 'es' ? 'Copiado' : 'Copied') : (language === 'es' ? 'Copiar Fase' : 'Copy Phase')}</span>
                  </button>
                </div>

                <p className="text-xs text-slate-300 font-mono bg-slate-900/80 p-3 rounded-lg border border-slate-800 leading-relaxed">
                  {ph.promptText}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: FILE STRUCTURE */}
      {activeTab === 'structure' && (
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <FolderTree className="w-4 h-4 text-indigo-400" />
              <span>{language === 'es' ? 'Arquitectura de Directorios Sugerida' : 'Recommended Folder Architecture'}</span>
            </h3>
            <button
              onClick={() => handleCopy(promptResult.folderStructure, 'folder_struct')}
              className="flex items-center gap-1.5 px-3 py-1 text-xs bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 rounded-lg cursor-pointer"
            >
              {copiedTab === 'folder_struct' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedTab === 'folder_struct' ? (language === 'es' ? 'Copiado' : 'Copied') : (language === 'es' ? 'Copiar Estructura' : 'Copy Tree')}</span>
            </button>
          </div>

          <pre className="font-mono text-xs p-4 bg-slate-900 rounded-xl text-indigo-300 overflow-x-auto leading-relaxed border border-slate-800">
            {promptResult.folderStructure}
          </pre>
        </div>
      )}

      {/* TAB 4: DB SCHEMA & TYPES */}
      {activeTab === 'db' && (
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Database className="w-4 h-4 text-emerald-400" />
              <span>{language === 'es' ? 'Modelos de Datos y Tipos TypeScript' : 'Data Models & TypeScript Interfaces'}</span>
            </h3>
            <button
              onClick={() => handleCopy(promptResult.dbSchema, 'db_schema')}
              className="flex items-center gap-1.5 px-3 py-1 text-xs bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 rounded-lg cursor-pointer"
            >
              {copiedTab === 'db_schema' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedTab === 'db_schema' ? (language === 'es' ? 'Copiado' : 'Copied') : (language === 'es' ? 'Copiar Esquema' : 'Copy Models')}</span>
            </button>
          </div>

          <pre className="font-mono text-xs p-4 bg-slate-900 rounded-xl text-emerald-300 overflow-x-auto leading-relaxed border border-slate-800">
            {promptResult.dbSchema}
          </pre>
        </div>
      )}

      {/* TAB 5: QUALITY CHECKLIST */}
      {activeTab === 'checklist' && (
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-6">
          <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
            <CheckSquare className="w-4 h-4 text-amber-400" />
            <span>{language === 'es' ? 'Lista de Verificación de Calidad (QA)' : 'Quality Assurance Checklist'}</span>
          </h3>

          <div className="space-y-3">
            {promptResult.qualityChecklist.map((item, idx) => (
              <div key={idx} className="flex items-start gap-3 p-3 bg-slate-900/80 rounded-xl border border-slate-800">
                <CheckSquare className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                <span className="text-xs text-slate-200 font-medium">{item}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Bottom Sandbox Launch Callout */}
      <div className="mt-8 bg-gradient-to-r from-indigo-900/40 via-purple-900/30 to-slate-900 border border-indigo-500/30 rounded-2xl p-6 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
        <div>
          <h4 className="text-sm font-bold text-white flex items-center gap-2 mb-1">
            <Sparkles className="w-4 h-4 text-indigo-400" />
            <span>{language === 'es' ? '¿Quieres ver cómo funciona este prompt ahora mismo?' : 'Want to preview how this prompt runs right now?'}</span>
          </h4>
          <p className="text-xs text-slate-300">
            {language === 'es'
              ? 'Ejecuta una simulación interactiva con nuestro sandbox de IA integrado para visualizar la estructura del código.'
              : 'Run a live interactive simulation inside our built-in AI sandbox to test code responses.'}
          </p>
        </div>

        <button
          onClick={onTestInSimulator}
          className="px-5 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-emerald-500/20 transition-all flex items-center gap-2 shrink-0 cursor-pointer"
        >
          <Play className="w-4 h-4 fill-slate-950" />
          <span>{language === 'es' ? 'Simular en IA Sandbox' : 'Run in AI Sandbox'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

    </div>
  );
};
