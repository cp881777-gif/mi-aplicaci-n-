import React from 'react';
import { Bookmark, Wand2, Code2, Globe } from 'lucide-react';
import { Language } from '../types';

interface NavbarProps {
  language: Language;
  onLanguageToggle: () => void;
  savedCount: number;
  onOpenSavedModal: () => void;
  onOpenEnhancerModal: () => void;
  onResetWizard: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  language,
  onLanguageToggle,
  savedCount,
  onOpenSavedModal,
  onOpenEnhancerModal,
  onResetWizard
}) => {
  return (
    <nav className="sticky top-0 z-40 border-b border-slate-800 bg-slate-950/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Brand Logo */}
          <div 
            onClick={onResetWizard}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 p-[2px] shadow-lg shadow-indigo-500/20 group-hover:scale-105 transition-transform">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Code2 className="w-5 h-5 text-indigo-400 group-hover:rotate-12 transition-transform" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg bg-gradient-to-r from-white via-slate-200 to-indigo-300 bg-clip-text text-transparent">
                  PromptCrafter
                </span>
                <span className="px-1.5 py-0.5 text-[10px] font-semibold bg-indigo-500/20 text-indigo-300 rounded border border-indigo-500/30">
                  STUDIO
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                {language === 'es' ? 'Generador de Prompts para Apps' : 'App Prompt Architecture Engine'}
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* AI Idea Enhancer */}
            <button
              onClick={onOpenEnhancerModal}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-gradient-to-r from-indigo-500/20 to-purple-500/20 hover:from-indigo-500/30 hover:to-purple-500/30 text-indigo-300 border border-indigo-500/30 rounded-lg transition-all shadow-sm cursor-pointer"
              title={language === 'es' ? 'Transforma una idea corta en prompt completo' : 'Transform brief idea into full prompt'}
            >
              <Wand2 className="w-3.5 h-3.5 text-purple-400 animate-pulse" />
              <span className="hidden sm:inline">
                {language === 'es' ? 'Mejorar Idea' : 'Enhance Idea'}
              </span>
            </button>

            {/* Saved Prompts */}
            <button
              onClick={onOpenSavedModal}
              className="relative flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg transition-all cursor-pointer"
            >
              <Bookmark className="w-3.5 h-3.5 text-amber-400" />
              <span>{language === 'es' ? 'Guardados' : 'Saved'}</span>
              {savedCount > 0 && (
                <span className="px-1.5 py-0.2 text-[10px] font-bold bg-amber-500 text-slate-950 rounded-full">
                  {savedCount}
                </span>
              )}
            </button>

            {/* Language Switcher */}
            <button
              onClick={onLanguageToggle}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 rounded-lg transition-all cursor-pointer"
              title={language === 'es' ? 'Cambiar a Inglés' : 'Switch to Spanish'}
            >
              <Globe className="w-3.5 h-3.5 text-blue-400" />
              <span className="font-semibold uppercase">{language}</span>
            </button>
          </div>

        </div>
      </div>
    </nav>
  );
};
