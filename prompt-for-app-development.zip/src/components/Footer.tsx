import React from 'react';
import { Terminal, Code2, Sparkles, Heart } from 'lucide-react';
import { Language } from '../types';

interface FooterProps {
  language: Language;
}

export const Footer: React.FC<FooterProps> = ({ language }) => {
  return (
    <footer className="mt-20 border-t border-slate-800/80 bg-slate-950 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 mb-8 text-xs text-slate-400">
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Code2 className="w-5 h-5 text-indigo-400" />
            <span className="font-bold text-sm text-white">PromptCrafter Studio</span>
          </div>
          <p className="leading-relaxed text-slate-400">
            {language === 'es'
              ? 'Herramienta profesional para estructurar prompts maestros de desarrollo de software para Claude, ChatGPT, Cursor, Bolt.new y más.'
              : 'Professional tool to architect master software engineering prompts for Claude, ChatGPT, Cursor, Bolt.new and beyond.'}
          </p>
        </div>

        <div>
          <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-3 flex items-center gap-1.5">
            <Terminal className="w-4 h-4 text-indigo-400" />
            <span>{language === 'es' ? 'Consejos de Prompting' : 'Prompt Engineering Tips'}</span>
          </h4>
          <ul className="space-y-1.5 text-slate-400">
            <li>• {language === 'es' ? 'Sé explícito con la estructura de archivos' : 'Be explicit with folder layout'}</li>
            <li>• {language === 'es' ? 'Pide código completo sin comentarios TODO' : 'Request full code without TODO stubs'}</li>
            <li>• {language === 'es' ? 'Específica los tipos estritos de TypeScript' : 'Specify strict TypeScript definitions'}</li>
            <li>• {language === 'es' ? 'Divide tareas complejas en fases cortas' : 'Decompose big builds into short phases'}</li>
          </ul>
        </div>

        <div>
          <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-3 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span>{language === 'es' ? 'Asistentes Compatibles' : 'Compatible AI Assistants'}</span>
          </h4>
          <div className="flex flex-wrap gap-1.5">
            {['Claude 3.7 Sonnet', 'ChatGPT-4o', 'Cursor Composer', 'Bolt.new', 'v0 by Vercel', 'Windsurf Cascade'].map((tool) => (
              <span key={tool} className="px-2 py-1 bg-slate-900 border border-slate-800 rounded text-slate-300">
                {tool}
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto pt-6 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
        <p>© {new Date().getFullYear()} PromptCrafter Studio. {language === 'es' ? 'Todos los derechos reservados.' : 'All rights reserved.'}</p>
        <p className="flex items-center gap-1">
          <span>{language === 'es' ? 'Diseñado con' : 'Designed with'}</span>
          <Heart className="w-3.5 h-3.5 text-pink-500 fill-pink-500" />
          <span>{language === 'es' ? 'para desarrolladores' : 'for software developers'}</span>
        </p>
      </div>
    </footer>
  );
};
