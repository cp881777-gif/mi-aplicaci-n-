import React, { useState, useEffect } from 'react';
import { X, Check, RefreshCw, Layers, Sparkles, Terminal, FileCode2 } from 'lucide-react';
import { AppPromptConfig, Language } from '../types';

interface AiSimulatorProps {
  language: Language;
  isOpen: boolean;
  onClose: () => void;
  config: AppPromptConfig;
}

export const AiSimulatorModal: React.FC<AiSimulatorProps> = ({
  language,
  isOpen,
  onClose,
  config
}) => {
  const [status, setStatus] = useState<'idle' | 'generating' | 'completed'>('idle');
  const [progress, setProgress] = useState(0);
  const [activeSimTab, setActiveTab] = useState<'response' | 'files' | 'preview'>('response');
  const [simulatedLogs, setSimulatedLogs] = useState<string[]>([]);

  useEffect(() => {
    if (isOpen && status === 'idle') {
      runSimulation();
    }
  }, [isOpen]);

  const runSimulation = () => {
    setStatus('generating');
    setProgress(10);
    setSimulatedLogs([
      language === 'es' ? '🤖 Analizando el prompt maestro y requerimientos...' : '🤖 Parsing master prompt and project requirements...',
      language === 'es' ? '🏗️ Configurando la arquitectura del proyecto...' : '🏗️ Configuring project structure & exports...'
    ]);

    setTimeout(() => {
      setProgress(40);
      setSimulatedLogs(prev => [
        ...prev,
        language === 'es' ? '⚙️ Generando esquemas de datos TypeScript & Prisma...' : '⚙️ Generating TypeScript interfaces & Prisma schemas...',
        language === 'es' ? `🎨 Creando componentes con ${config.stack.uiLibrary}...` : `🎨 Styling components with ${config.stack.uiLibrary}...`
      ]);
    }, 1200);

    setTimeout(() => {
      setProgress(75);
      setSimulatedLogs(prev => [
        ...prev,
        language === 'es' ? `🔐 Configurando autenticación con ${config.stack.auth}...` : `🔐 Hooking up authentication with ${config.stack.auth}...`,
        language === 'es' ? '✨ Agregando estados de carga y manejo de errores...' : '✨ Adding loading skeletons and error boundaries...'
      ]);
    }, 2400);

    setTimeout(() => {
      setProgress(100);
      setStatus('completed');
      setSimulatedLogs(prev => [
        ...prev,
        language === 'es' ? '✅ ¡Aplicación prototipo generada con éxito en 0.8s!' : '✅ Prototype application successfully built in 0.8s!'
      ]);
    }, 3600);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <h3 className="font-bold text-white text-sm flex items-center gap-2">
                <span>{language === 'es' ? 'AI Sandbox Simulator' : 'AI Sandbox Simulator'}</span>
                <span className="text-[10px] px-2 py-0.5 bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/20">
                  {config.targetAi.toUpperCase()}
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                {language === 'es' ? `Ejecución en tiempo real de "${config.title}"` : `Live prompt run for "${config.title}"`}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-lg cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Progress Bar */}
        {status === 'generating' && (
          <div className="w-full bg-slate-950 h-1">
            <div
              className="bg-gradient-to-r from-emerald-500 to-teal-400 h-1 transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
        )}

        {/* Simulator Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-950/60 px-6">
          <button
            onClick={() => setActiveTab('response')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 cursor-pointer transition-colors ${
              activeSimTab === 'response'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>{language === 'es' ? 'Respuesta IA (Console)' : 'AI Response Stream'}</span>
          </button>

          <button
            onClick={() => setActiveTab('files')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 cursor-pointer transition-colors ${
              activeSimTab === 'files'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <FileCode2 className="w-3.5 h-3.5" />
            <span>{language === 'es' ? 'Archivos Generados (3)' : 'Generated Files (3)'}</span>
          </button>

          <button
            onClick={() => setActiveTab('preview')}
            className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 cursor-pointer transition-colors ${
              activeSimTab === 'preview'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>{language === 'es' ? 'Vista Previa UI Prototipo' : 'Prototype UI Preview'}</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 font-mono text-xs">
          
          {/* TAB 1: Console response stream */}
          {activeSimTab === 'response' && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                {simulatedLogs.map((log, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-slate-300">
                    <span className="text-slate-600">[{new Date().toLocaleTimeString()}]</span>
                    <span>{log}</span>
                  </div>
                ))}

                {status === 'generating' && (
                  <div className="flex items-center gap-2 text-emerald-400 animate-pulse pt-2">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>{language === 'es' ? 'Generando código ejecutable...' : 'Synthesizing clean typescript components...'}</span>
                  </div>
                )}
              </div>

              {status === 'completed' && (
                <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-300 space-y-2">
                  <p className="font-bold flex items-center gap-2 text-sm">
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>{language === 'es' ? '¡Prompt Validador Exitoso!' : 'Prompt Verified Successfully!'}</span>
                  </p>
                  <p className="text-xs text-slate-300 font-sans leading-relaxed">
                    {language === 'es' 
                      ? `Este prompt maestro provee todas las especificaciones necesarias para que ${config.targetAi.toUpperCase()} genere la aplicación "${config.title}" sin vacíos ni ambigüedades.`
                      : `This master prompt supplies full details for ${config.targetAi.toUpperCase()} to produce "${config.title}" without ambiguity.`}
                  </p>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: Generated starter files */}
          {activeSimTab === 'files' && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                <div className="text-indigo-400 font-bold mb-2 flex items-center justify-between">
                  <span>📄 src/types/index.ts</span>
                  <span className="text-[10px] text-slate-500">TypeScript</span>
                </div>
                <pre className="text-[11px] text-slate-300 bg-slate-900 p-3 rounded-lg overflow-x-auto">
{`export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'user';
}

export interface AppState {
  user: User | null;
  isLoading: boolean;
  theme: 'dark' | 'light';
}`}
                </pre>
              </div>

              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                <div className="text-indigo-400 font-bold mb-2 flex items-center justify-between">
                  <span>📄 src/App.tsx</span>
                  <span className="text-[10px] text-slate-500">React + Tailwind</span>
                </div>
                <pre className="text-[11px] text-slate-300 bg-slate-900 p-3 rounded-lg overflow-x-auto">
{`import React from 'react';

export default function App() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center">
      <div className="p-8 bg-slate-900 border border-slate-800 rounded-2xl shadow-xl">
        <h1 className="text-2xl font-bold">${config.title}</h1>
        <p className="text-slate-400 text-sm mt-2">${config.description}</p>
      </div>
    </div>
  );
}`}
                </pre>
              </div>
            </div>
          )}

          {/* TAB 3: UI Prototype Preview */}
          {activeSimTab === 'preview' && (
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-6 font-sans">
              <div className="max-w-md mx-auto bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl">
                <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-indigo-500" />
                    <span className="font-bold text-white text-sm">{config.title}</span>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 bg-emerald-500/20 text-emerald-300 rounded-full font-semibold">
                    PROTOTIPO
                  </span>
                </div>

                <div className="space-y-4">
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                    <span className="text-xs text-slate-400">Descripción</span>
                    <p className="text-xs font-medium text-slate-200 mt-0.5">{config.description}</p>
                  </div>

                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
                    <div>
                      <span className="text-xs text-slate-400">Frontend & Backend</span>
                      <p className="text-xs font-semibold text-indigo-300">{config.stack.frontend}</p>
                    </div>
                    <span className="px-2 py-1 bg-slate-900 text-xs font-bold text-slate-300 rounded">
                      {config.stack.backend.split(' ')[0]}
                    </span>
                  </div>

                  <button className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl transition-colors cursor-pointer">
                    {language === 'es' ? 'Probar Acción Demo' : 'Test Interactive Action'}
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
          <button
            onClick={runSimulation}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-800 rounded-lg cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>{language === 'es' ? 'Re-Ejecutar' : 'Re-Run'}</span>
          </button>

          <button
            onClick={onClose}
            className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl cursor-pointer"
          >
            {language === 'es' ? 'Cerrar Sandbox' : 'Close Sandbox'}
          </button>
        </div>

      </div>
    </div>
  );
};
