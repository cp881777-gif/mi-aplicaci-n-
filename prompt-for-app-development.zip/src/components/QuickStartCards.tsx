import React from 'react';
import { Sparkles, ShoppingCart, Cpu, BarChart3, Users, Activity, ArrowRight, CheckCircle2 } from 'lucide-react';
import { PREBUILT_TEMPLATES } from '../data/prebuiltPrompts';
import { PrebuiltTemplate, Language } from '../types';

interface QuickStartCardsProps {
  language: Language;
  onSelectTemplate: (template: PrebuiltTemplate) => void;
}

export const QuickStartCards: React.FC<QuickStartCardsProps> = ({
  language,
  onSelectTemplate
}) => {
  const getIcon = (name: string) => {
    switch (name) {
      case 'Sparkles': return <Sparkles className="w-5 h-5 text-purple-400" />;
      case 'ShoppingCart': return <ShoppingCart className="w-5 h-5 text-emerald-400" />;
      case 'Cpu': return <Cpu className="w-5 h-5 text-blue-400" />;
      case 'BarChart3': return <BarChart3 className="w-5 h-5 text-amber-400" />;
      case 'Users': return <Users className="w-5 h-5 text-rose-400" />;
      case 'Activity': return <Activity className="w-5 h-5 text-teal-400" />;
      default: return <Sparkles className="w-5 h-5 text-indigo-400" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-2">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-indigo-400" />
            <span>
              {language === 'es' ? 'Plantillas Listas para Usar (1-Clic)' : 'Ready-to-Use Templates (1-Click)'}
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            {language === 'es'
              ? 'Selecciona una arquitectura pre-configurada para obtener inmediatamente el prompt maestro'
              : 'Select a pre-built project structure to get an instant master prompt'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {PREBUILT_TEMPLATES.map((tmpl) => (
          <div
            key={tmpl.id}
            onClick={() => onSelectTemplate(tmpl)}
            className="group relative bg-slate-900/70 border border-slate-800 hover:border-indigo-500/50 rounded-2xl p-5 transition-all duration-300 hover:shadow-xl hover:shadow-indigo-500/10 hover:-translate-y-1 cursor-pointer flex flex-col justify-between"
          >
            {/* Top Bar Accent */}
            <div className={`absolute top-0 left-6 right-6 h-[2px] bg-gradient-to-r ${tmpl.color} rounded-full opacity-60 group-hover:opacity-100 transition-opacity`} />

            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700/80 flex items-center justify-center group-hover:scale-110 transition-transform">
                  {getIcon(tmpl.iconName)}
                </div>
                <span className="text-[11px] font-medium text-slate-400 bg-slate-800/80 px-2.5 py-1 rounded-full border border-slate-700/50">
                  {tmpl.config.stack.frontend.split(' ')[0]}
                </span>
              </div>

              <h3 className="text-base font-bold text-white group-hover:text-indigo-300 transition-colors mb-1.5">
                {tmpl.title[language]}
              </h3>

              <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed mb-4">
                {tmpl.subtitle[language]}
              </p>

              {/* Tags */}
              <div className="flex flex-wrap gap-1.5 mb-4">
                {tmpl.tags.map((tag) => (
                  <span
                    key={tag}
                    className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700/50 font-medium"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Card Action Footer */}
            <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-indigo-400 font-semibold group-hover:text-indigo-300">
              <span className="flex items-center gap-1 text-[11px] text-slate-400">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                {tmpl.config.features.auth ? 'Auth + DB' : 'Config Listo'}
              </span>
              <span className="flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                {language === 'es' ? 'Obtener Prompt' : 'Get Prompt'}
                <ArrowRight className="w-3.5 h-3.5" />
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
