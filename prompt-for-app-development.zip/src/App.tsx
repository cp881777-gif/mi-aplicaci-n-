import { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HeroHeader } from './components/HeroHeader';
import { QuickStartCards } from './components/QuickStartCards';
import { WizardStepByStep } from './components/WizardStepByStep';
import { PromptViewer } from './components/PromptViewer';
import { AiSimulatorModal } from './components/AiSimulatorModal';
import { PromptEnhancerModal } from './components/PromptEnhancerModal';
import { SavedPromptsModal } from './components/SavedPromptsModal';
import { Footer } from './components/Footer';
import { Language, AppPromptConfig, GeneratedPromptResult, PrebuiltTemplate } from './types';
import { generateSoftwarePrompt } from './utils/promptGenerator';
import { PREBUILT_TEMPLATES } from './data/prebuiltPrompts';

export function App() {
  const [language, setLanguage] = useState<Language>('es');
  const [activeView, setActiveView] = useState<'home' | 'wizard' | 'viewer'>('home');
  const [currentConfig, setCurrentConfig] = useState<AppPromptConfig | null>(null);
  const [promptResult, setPromptResult] = useState<GeneratedPromptResult | null>(null);
  const [wizardInitialConfig, setWizardInitialConfig] = useState<AppPromptConfig | undefined>(undefined);

  // Modals
  const [isSimulatorOpen, setIsSimulatorOpen] = useState(false);
  const [isEnhancerOpen, setIsEnhancerOpen] = useState(false);
  const [isSavedModalOpen, setIsSavedModalOpen] = useState(false);

  // Saved Prompts Persistence
  const [savedPrompts, setSavedPrompts] = useState<AppPromptConfig[]>(() => {
    try {
      const item = localStorage.getItem('promptcrafter_saved');
      return item ? JSON.parse(item) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('promptcrafter_saved', JSON.stringify(savedPrompts));
    } catch (e) {
      console.error('Could not save to localStorage', e);
    }
  }, [savedPrompts]);

  // Initial auto-generation on first load using default SaaS template so user immediately sees a working prompt!
  useEffect(() => {
    if (!promptResult) {
      const defaultTemplate = PREBUILT_TEMPLATES[0];
      handleGeneratePrompt(defaultTemplate.config);
      setActiveView('viewer');
    }
  }, []);

  const handleToggleLanguage = () => {
    setLanguage(prev => (prev === 'es' ? 'en' : 'es'));
  };

  const handleGeneratePrompt = (config: AppPromptConfig) => {
    const result = generateSoftwarePrompt(config);
    setCurrentConfig(config);
    setPromptResult(result);
    setActiveView('viewer');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectTemplate = (template: PrebuiltTemplate) => {
    handleGeneratePrompt(template.config);
  };

  const handleSavePrompt = (config: AppPromptConfig) => {
    if (!config) return;
    const exists = savedPrompts.some(p => p.id === config.id || p.title === config.title);
    if (!exists) {
      const newPrompt: AppPromptConfig = {
        ...config,
        id: config.id || `prompt_${Date.now()}`,
        createdAt: new Date().toISOString()
      };
      setSavedPrompts(prev => [newPrompt, ...prev]);
    }
  };

  const handleDeleteSavedPrompt = (id: string) => {
    setSavedPrompts(prev => prev.filter(p => p.id !== id));
  };

  const handleApplyEnhancement = (partial: Partial<AppPromptConfig>) => {
    const mergedConfig: AppPromptConfig = {
      title: partial.title || 'App Personalizada',
      description: partial.description || '',
      targetAudience: partial.targetAudience || 'Usuarios generales',
      appType: partial.appType || 'saas',
      complexity: 'standard',
      stack: {
        frontend: 'React + Vite (TypeScript)',
        uiLibrary: 'Tailwind CSS v4',
        backend: 'Supabase (BaaS)',
        database: 'Supabase PostgreSQL',
        auth: 'Supabase Auth',
        payments: 'Stripe Payments / Subscriptions',
        deploy: 'Vercel'
      },
      features: {
        auth: true,
        darkMode: true,
        realtime: true,
        subscriptions: true,
        adminPanel: true,
        fileUpload: true,
        i18n: false,
        aiIntegration: true,
        searchFilter: true,
        exportPdfCsv: true,
        rbac: true,
        notifications: true,
        customFeatures: []
      },
      targetAi: 'claude',
      language
    };

    setWizardInitialConfig(mergedConfig);
    setActiveView('wizard');
  };

  const isCurrentSaved = Boolean(
    currentConfig && savedPrompts.some(p => p.title === currentConfig.title)
  );

  return (
    <div className="min-h-screen bg-[#0b0f19] text-slate-100 selection:bg-indigo-500 selection:text-white flex flex-col font-sans">
      
      {/* Navigation */}
      <Navbar
        language={language}
        onLanguageToggle={handleToggleLanguage}
        savedCount={savedPrompts.length}
        onOpenSavedModal={() => setIsSavedModalOpen(true)}
        onOpenEnhancerModal={() => setIsEnhancerOpen(true)}
        onResetWizard={() => {
          setWizardInitialConfig(undefined);
          setActiveView('home');
        }}
      />

      {/* Main Views Switcher */}
      <main className="flex-1">
        
        {/* VIEW 1: HOME (Hero + Quick Templates) */}
        {activeView === 'home' && (
          <div>
            <HeroHeader
              language={language}
              onStartCustomWizard={() => {
                setWizardInitialConfig(undefined);
                setActiveView('wizard');
              }}
              onOpenEnhancerModal={() => setIsEnhancerOpen(true)}
            />

            <QuickStartCards
              language={language}
              onSelectTemplate={handleSelectTemplate}
            />
          </div>
        )}

        {/* VIEW 2: INTERACTIVE STEP-BY-STEP WIZARD */}
        {activeView === 'wizard' && (
          <WizardStepByStep
            language={language}
            initialConfig={wizardInitialConfig}
            onGeneratePrompt={handleGeneratePrompt}
            onCancel={() => setActiveView(promptResult ? 'viewer' : 'home')}
          />
        )}

        {/* VIEW 3: PROMPT VIEWER & TABS */}
        {activeView === 'viewer' && promptResult && currentConfig && (
          <div>
            {/* Quick Banner Navigation */}
            <div className="bg-slate-900/60 border-b border-slate-800/80 py-3 px-4 text-center text-xs text-slate-400 flex items-center justify-center gap-4">
              <span>
                {language === 'es' ? '¿Quieres modificar los parámetros?' : 'Need to adjust prompt specifications?'}
              </span>
              <button
                onClick={() => {
                  setWizardInitialConfig(currentConfig);
                  setActiveView('wizard');
                }}
                className="px-3 py-1 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 rounded-lg border border-indigo-500/30 font-semibold cursor-pointer"
              >
                {language === 'es' ? '✏️ Editar en Diseñador' : '✏️ Edit in Builder'}
              </button>
              <button
                onClick={() => setActiveView('home')}
                className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg border border-slate-700 font-semibold cursor-pointer"
              >
                {language === 'es' ? '🏠 Ver Plantillas' : '🏠 All Templates'}
              </button>
            </div>

            <PromptViewer
              language={language}
              promptResult={promptResult}
              config={currentConfig}
              onSavePrompt={handleSavePrompt}
              isSaved={isCurrentSaved}
              onTestInSimulator={() => setIsSimulatorOpen(true)}
              onResetToWizard={() => {
                setWizardInitialConfig(undefined);
                setActiveView('wizard');
              }}
            />
          </div>
        )}

      </main>

      {/* Footer */}
      <Footer language={language} />

      {/* Modals */}
      {currentConfig && (
        <AiSimulatorModal
          language={language}
          isOpen={isSimulatorOpen}
          onClose={() => setIsSimulatorOpen(false)}
          config={currentConfig}
        />
      )}

      <PromptEnhancerModal
        language={language}
        isOpen={isEnhancerOpen}
        onClose={() => setIsEnhancerOpen(false)}
        onApplyEnhancement={handleApplyEnhancement}
      />

      <SavedPromptsModal
        language={language}
        isOpen={isSavedModalOpen}
        onClose={() => setIsSavedModalOpen(false)}
        savedPrompts={savedPrompts}
        onSelectSavedPrompt={(cfg) => {
          handleGeneratePrompt(cfg);
        }}
        onDeleteSavedPrompt={handleDeleteSavedPrompt}
      />

    </div>
  );
}

export default App;
